﻿namespace Faktury_JK
{
    partial class UCKonfiguracja
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCKonfiguracja));
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label hasłoLabel;
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnZapisz = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.uzytkownicyIDLabel1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.txtSMTPEmail = new System.Windows.Forms.TextBox();
            this.txtPasswordEmail = new System.Windows.Forms.TextBox();
            this.txtUsernameEmail = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            hasłoLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnZapisz);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.uzytkownicyIDLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 637);
            this.panel1.TabIndex = 60;
            // 
            // btnZapisz
            // 
            this.btnZapisz.BackColor = System.Drawing.Color.Transparent;
            this.btnZapisz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapisz.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZapisz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZapisz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZapisz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapisz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZapisz.Image = ((System.Drawing.Image)(resources.GetObject("btnZapisz.Image")));
            this.btnZapisz.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZapisz.Location = new System.Drawing.Point(25, 65);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(150, 60);
            this.btnZapisz.TabIndex = 54;
            this.btnZapisz.Text = "Zapisz   ";
            this.btnZapisz.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZapisz.UseVisualStyleBackColor = false;
            this.btnZapisz.Click += new System.EventHandler(this.btnZapisz_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(21, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 20);
            this.label3.TabIndex = 50;
            this.label3.Text = "Konfiguracja:";
            // 
            // uzytkownicyIDLabel1
            // 
            this.uzytkownicyIDLabel1.Location = new System.Drawing.Point(128, -32);
            this.uzytkownicyIDLabel1.Name = "uzytkownicyIDLabel1";
            this.uzytkownicyIDLabel1.Size = new System.Drawing.Size(47, 23);
            this.uzytkownicyIDLabel1.TabIndex = 51;
            this.uzytkownicyIDLabel1.Text = "label2";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(label1);
            this.groupBox1.Controls.Add(this.txtSMTPEmail);
            this.groupBox1.Controls.Add(label2);
            this.groupBox1.Controls.Add(this.txtPasswordEmail);
            this.groupBox1.Controls.Add(hasłoLabel);
            this.groupBox1.Controls.Add(this.txtUsernameEmail);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.Location = new System.Drawing.Point(226, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 216);
            this.groupBox1.TabIndex = 76;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kwalifikacje Nadawcy/Email:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(44, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 48);
            this.label5.TabIndex = 71;
            this.label5.Text = "Połączenie nieszyfrowane.\r\nUruchomienie usługi wymaga akceptacji\r\nLess Secure App" +
    "s dla konta Gmail.\r\n";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(44, 187);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(288, 16);
            this.linkLabel1.TabIndex = 70;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://myaccount.google.com/lesssecureapps";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            label1.Location = new System.Drawing.Point(44, 101);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(49, 16);
            label1.TabIndex = 69;
            label1.Text = "SMTP:";
            // 
            // txtSMTPEmail
            // 
            this.txtSMTPEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtSMTPEmail.Location = new System.Drawing.Point(111, 98);
            this.txtSMTPEmail.MaxLength = 22;
            this.txtSMTPEmail.Name = "txtSMTPEmail";
            this.txtSMTPEmail.Size = new System.Drawing.Size(247, 22);
            this.txtSMTPEmail.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            label2.Location = new System.Drawing.Point(44, 69);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(50, 16);
            label2.TabIndex = 67;
            label2.Text = "Hasło:";
            // 
            // txtPasswordEmail
            // 
            this.txtPasswordEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPasswordEmail.Location = new System.Drawing.Point(111, 66);
            this.txtPasswordEmail.MaxLength = 22;
            this.txtPasswordEmail.Name = "txtPasswordEmail";
            this.txtPasswordEmail.PasswordChar = '*';
            this.txtPasswordEmail.Size = new System.Drawing.Size(247, 22);
            this.txtPasswordEmail.TabIndex = 1;
            // 
            // hasłoLabel
            // 
            hasłoLabel.AutoSize = true;
            hasłoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            hasłoLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            hasłoLabel.Location = new System.Drawing.Point(16, 37);
            hasłoLabel.Name = "hasłoLabel";
            hasłoLabel.Size = new System.Drawing.Size(78, 16);
            hasłoLabel.TabIndex = 65;
            hasłoLabel.Text = "Użytkownik:";
            // 
            // txtUsernameEmail
            // 
            this.txtUsernameEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtUsernameEmail.Location = new System.Drawing.Point(111, 34);
            this.txtUsernameEmail.MaxLength = 44;
            this.txtUsernameEmail.Name = "txtUsernameEmail";
            this.txtUsernameEmail.Size = new System.Drawing.Size(247, 22);
            this.txtUsernameEmail.TabIndex = 0;
            // 
            // UCKonfiguracja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "UCKonfiguracja";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(1078, 647);
            this.Load += new System.EventHandler(this.UCKonfiguracja_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label uzytkownicyIDLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TextBox txtSMTPEmail;
        private System.Windows.Forms.TextBox txtPasswordEmail;
        private System.Windows.Forms.TextBox txtUsernameEmail;
    }
}
