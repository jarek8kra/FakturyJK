﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FProduktyDodaj : Form
    {
        public FProduktyDodaj()
        {
            InitializeComponent();
        }

        private void CenaTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
    (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        void Sprawdzanie()
        {
            if(NazwaProduktuTextBox.Text!=string.Empty&&
                CenaTextBox.Text!=string.Empty&&
                VattextBox.Text!=string.Empty)
            {
                btnZapisz.Enabled = true;
            }
            else
            {
                btnZapisz.Enabled = false;
            }
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("AddProdukty", con);

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@nazwa", SqlDbType.VarChar).Value = NazwaProduktuTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@cena", SqlDbType.VarChar).Value = CenaTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@vat", SqlDbType.Int).Value = Int32.Parse(VattextBox.Text.Trim());
            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }

        private void NazwaProduktuTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void CenaTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void VattextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);//tylko cyfry
        }

        private void VattextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }
    }
}
