﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Faktury_JK
{
    public partial class UCOdbiorcy : UserControl
    {
        public UCOdbiorcy()
        {
            InitializeComponent();
        }
        private static UCOdbiorcy _instance;
        public static UCOdbiorcy Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCOdbiorcy();
                return _instance;
            }
        }

        private void UCOdbiorcy_Load(object sender, EventArgs e)
        {
            Odswiezanie();
            ZliczanieRekordow();
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            FOdbiorcyDodaj fod = new FOdbiorcyDodaj();
            DialogResult result = fod.ShowDialog();
            Odswiezanie();
        }
        BindingSource bs;
        void Odswiezanie()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("OdbiorcyView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            bs = new BindingSource();
            bs.DataSource = dt;
            dataGridView1.Columns["Id"].Visible = false;
            dataGridView1.Columns["Email"].Width = 170;
            labelIDOdbiorcyView.DataBindings.Clear();
            labelIDOdbiorcyView.DataBindings.Add("Text", dt, "Id");
            con.Close();
        }

        private void btnOdswiez_Click(object sender, EventArgs e)
        {
            Odswiezanie();
            ZliczanieRekordow();
        }
        public void ZliczanieRekordow()
        {
            lblCount.Text = dataGridView1.Rows.Count.ToString();
            int ile = dataGridView1.Rows.Count;
            if (ile > 0)
            {
                btnEdytuj.Enabled = true;
                btnUsun.Enabled = true;
            }
            else
            {
                btnEdytuj.Enabled = false;
                btnUsun.Enabled = false;
            }
        }

        private void txtNazwaFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Nazwa";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNazwaFilter.Text);
            ZliczanieRekordow();
        }

        private void txtAdres1Filter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "AdresUlicaNumer";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtAdres1Filter.Text);
            ZliczanieRekordow();
        }

        private void txtAdres2Filter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "AdresKodMiasto";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtAdres2Filter.Text);
            ZliczanieRekordow();
        }

        private void txtNIPFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "NIP";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNIPFilter.Text);
            ZliczanieRekordow();
        }

        private void txtREGONFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "REGON";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtREGONFilter.Text);
            ZliczanieRekordow();
        }
        private void txtEmailFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Email";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtEmailFilter.Text);
            ZliczanieRekordow();
        }

        private void btnEdytuj_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(labelIDOdbiorcyView.Text);
            FOdbiorcyEdytuj foe = new FOdbiorcyEdytuj(id);
            DialogResult result = foe.ShowDialog();
            Odswiezanie();
        }

        private void btnUsun_Click(object sender, EventArgs e)
        {
            string Nazwa = dataGridView1.CurrentRow.Cells[1].Value.ToString();

           if( MessageBox.Show("Usunąć odbiorcę: "+Nazwa+"?","Faktury JK",MessageBoxButtons.YesNo,MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ==DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
                SqlCommand cmd = new SqlCommand("DeleteOdbiorcaById", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = Int32.Parse(labelIDOdbiorcyView.Text);
                cmd.ExecuteNonQuery();
                con.Close();

                Odswiezanie();
                ZliczanieRekordow();
            }

        }

        private void txtNazwaFilter_Enter(object sender, EventArgs e)
        {
           // txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
            txtEmailFilter.Text = string.Empty;
        }

        private void txtAdres1Filter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
           // txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
            txtEmailFilter.Text = string.Empty;
        }

        private void txtAdres2Filter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            //txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
            txtEmailFilter.Text = string.Empty;
        }

        private void txtNIPFilter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
           // txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
            txtEmailFilter.Text = string.Empty;
        }

        private void txtREGONFilter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            //txtREGONFilter.Text = string.Empty;
            txtEmailFilter.Text = string.Empty;
        }
        private void txtEmailFilter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
            // txtEmailFilter.Text = string.Empty;
        }

        private void toolStripMenuDodaj_Click(object sender, EventArgs e)
        {
            btnDodaj_Click(null, null);
        }

        private void toolStripMenuEdytuj_Click(object sender, EventArgs e)
        {
            btnEdytuj_Click(null, null);
        }

        private void toolStripMenuUsun_Click(object sender, EventArgs e)
        {
            btnUsun_Click(null, null);
        }

        private void toolStripMenuOdswiez_Click(object sender, EventArgs e)
        {
            btnOdswiez_Click(null, null);
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                dataGridView1.Rows[e.RowIndex].Selected = true;
                dataGridView1.Focus();
            }
        }


    }
}
