﻿namespace Faktury_JK
{
    partial class UCUtworzFakture
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCUtworzFakture));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelFaktura = new System.Windows.Forms.Panel();
            this.panelpodsumowanie = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelNrKonta = new System.Windows.Forms.Label();
            this.labelTermin = new System.Windows.Forms.Label();
            this.labelForma = new System.Windows.Forms.Label();
            this.labelDozaplaty = new System.Windows.Forms.Label();
            this.labelRazem = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.Razema = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VATa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscNettoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscVATa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscBruttoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblNumerFaktury = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelDataWystawienia = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Lp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nazwa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Jm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ilosc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaNetto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscNetto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscVAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WartoscBrutto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxNabywca = new System.Windows.Forms.GroupBox();
            this.lblFNabywcaRegon = new System.Windows.Forms.Label();
            this.lblFNabywcaNIP = new System.Windows.Forms.Label();
            this.lblFNabywcaAdres2 = new System.Windows.Forms.Label();
            this.lblFNabywcaAdres1 = new System.Windows.Forms.Label();
            this.lblFNabywcaNazwa = new System.Windows.Forms.Label();
            this.groupBoxNadawca = new System.Windows.Forms.GroupBox();
            this.labelSprzedawcaREGON = new System.Windows.Forms.Label();
            this.labelSprzedawcaNIP = new System.Windows.Forms.Label();
            this.labelSprzedawcaAdres2 = new System.Windows.Forms.Label();
            this.labelSprzedawcaAdres1 = new System.Windows.Forms.Label();
            this.labelSprzedawcaNazwa = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.groupBoxNabywcaSelect = new System.Windows.Forms.GroupBox();
            this.btnNabywca = new System.Windows.Forms.Button();
            this.lblNabywcaRegon = new System.Windows.Forms.Label();
            this.lblNnabywcaNIP = new System.Windows.Forms.Label();
            this.lblNabywcaAdres2 = new System.Windows.Forms.Label();
            this.lblNabywcaAdres1 = new System.Windows.Forms.Label();
            this.lblNabywcaNazwa = new System.Windows.Forms.Label();
            this.lblFOdbiorcyID = new System.Windows.Forms.Label();
            this.labelCount = new System.Windows.Forms.Label();
            this.btnDodajProdukt = new System.Windows.Forms.Button();
            this.textBoxIlosc = new System.Windows.Forms.TextBox();
            this.lblNazwa = new System.Windows.Forms.Label();
            this.txtNazwaFilter = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.NazwaX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CenaX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VatX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IloscX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UsunX = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnZapisz = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panelFaktura.SuspendLayout();
            this.panelpodsumowanie.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBoxNabywca.SuspendLayout();
            this.groupBoxNadawca.SuspendLayout();
            this.groupBoxNabywcaSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // panelFaktura
            // 
            this.panelFaktura.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelFaktura.BackColor = System.Drawing.Color.White;
            this.panelFaktura.Controls.Add(this.panelpodsumowanie);
            this.panelFaktura.Controls.Add(this.dataGridView4);
            this.panelFaktura.Controls.Add(this.lblNumerFaktury);
            this.panelFaktura.Controls.Add(this.label7);
            this.panelFaktura.Controls.Add(this.labelDataWystawienia);
            this.panelFaktura.Controls.Add(this.label6);
            this.panelFaktura.Controls.Add(this.dataGridView1);
            this.panelFaktura.Controls.Add(this.groupBoxNabywca);
            this.panelFaktura.Controls.Add(this.groupBoxNadawca);
            this.panelFaktura.Location = new System.Drawing.Point(-2493, 190);
            this.panelFaktura.Name = "panelFaktura";
            this.panelFaktura.Size = new System.Drawing.Size(779, 883);
            this.panelFaktura.TabIndex = 0;
            // 
            // panelpodsumowanie
            // 
            this.panelpodsumowanie.Controls.Add(this.label12);
            this.panelpodsumowanie.Controls.Add(this.label11);
            this.panelpodsumowanie.Controls.Add(this.label10);
            this.panelpodsumowanie.Controls.Add(this.label9);
            this.panelpodsumowanie.Controls.Add(this.labelNrKonta);
            this.panelpodsumowanie.Controls.Add(this.labelTermin);
            this.panelpodsumowanie.Controls.Add(this.labelForma);
            this.panelpodsumowanie.Controls.Add(this.labelDozaplaty);
            this.panelpodsumowanie.Controls.Add(this.labelRazem);
            this.panelpodsumowanie.Controls.Add(this.label8);
            this.panelpodsumowanie.Controls.Add(this.label5);
            this.panelpodsumowanie.Controls.Add(this.label4);
            this.panelpodsumowanie.Controls.Add(this.label3);
            this.panelpodsumowanie.Controls.Add(this.label2);
            this.panelpodsumowanie.Location = new System.Drawing.Point(44, 310);
            this.panelpodsumowanie.Name = "panelpodsumowanie";
            this.panelpodsumowanie.Size = new System.Drawing.Size(711, 288);
            this.panelpodsumowanie.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(461, 218);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(157, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "Osoba upoważniona do odbioru";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(74, 218);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(179, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Osoba upoważniona do wystawienia";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(432, 205);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(229, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "..........................................................................";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(48, 205);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(229, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "..........................................................................";
            // 
            // labelNrKonta
            // 
            this.labelNrKonta.AutoSize = true;
            this.labelNrKonta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelNrKonta.Location = new System.Drawing.Point(143, 128);
            this.labelNrKonta.Name = "labelNrKonta";
            this.labelNrKonta.Size = new System.Drawing.Size(22, 16);
            this.labelNrKonta.TabIndex = 9;
            this.labelNrKonta.Text = "==";
            // 
            // labelTermin
            // 
            this.labelTermin.AutoSize = true;
            this.labelTermin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTermin.Location = new System.Drawing.Point(143, 103);
            this.labelTermin.Name = "labelTermin";
            this.labelTermin.Size = new System.Drawing.Size(22, 16);
            this.labelTermin.TabIndex = 8;
            this.labelTermin.Text = "==";
            // 
            // labelForma
            // 
            this.labelForma.AutoSize = true;
            this.labelForma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelForma.Location = new System.Drawing.Point(143, 78);
            this.labelForma.Name = "labelForma";
            this.labelForma.Size = new System.Drawing.Size(22, 16);
            this.labelForma.TabIndex = 7;
            this.labelForma.Text = "==";
            // 
            // labelDozaplaty
            // 
            this.labelDozaplaty.AutoSize = true;
            this.labelDozaplaty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelDozaplaty.Location = new System.Drawing.Point(143, 54);
            this.labelDozaplaty.Name = "labelDozaplaty";
            this.labelDozaplaty.Size = new System.Drawing.Size(24, 16);
            this.labelDozaplaty.TabIndex = 6;
            this.labelDozaplaty.Text = "==";
            // 
            // labelRazem
            // 
            this.labelRazem.AutoSize = true;
            this.labelRazem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelRazem.Location = new System.Drawing.Point(143, 33);
            this.labelRazem.Name = "labelRazem";
            this.labelRazem.Size = new System.Drawing.Size(22, 16);
            this.labelRazem.TabIndex = 5;
            this.labelRazem.Text = "==";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(25, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Nr Konta:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(25, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Termin płatności:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(25, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Forma płatności:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(25, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Do zapłaty:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(25, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Razem:";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Razema,
            this.VATa,
            this.WartoscNettoa,
            this.WartoscVATa,
            this.WartoscBruttoa});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView4.EnableHeadersVisualStyles = false;
            this.dataGridView4.GridColor = System.Drawing.Color.Black;
            this.dataGridView4.Location = new System.Drawing.Point(403, 269);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.RowTemplate.ReadOnly = true;
            this.dataGridView4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView4.Size = new System.Drawing.Size(332, 76);
            this.dataGridView4.TabIndex = 11;
            // 
            // Razema
            // 
            this.Razema.HeaderText = "";
            this.Razema.Name = "Razema";
            this.Razema.ReadOnly = true;
            this.Razema.Width = 70;
            // 
            // VATa
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.VATa.DefaultCellStyle = dataGridViewCellStyle2;
            this.VATa.HeaderText = "VAT[%]";
            this.VATa.Name = "VATa";
            this.VATa.ReadOnly = true;
            this.VATa.Width = 50;
            // 
            // WartoscNettoa
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "C2";
            dataGridViewCellStyle3.NullValue = null;
            this.WartoscNettoa.DefaultCellStyle = dataGridViewCellStyle3;
            this.WartoscNettoa.HeaderText = "Wartość Netto";
            this.WartoscNettoa.Name = "WartoscNettoa";
            this.WartoscNettoa.ReadOnly = true;
            this.WartoscNettoa.Width = 70;
            // 
            // WartoscVATa
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "C2";
            dataGridViewCellStyle4.NullValue = null;
            this.WartoscVATa.DefaultCellStyle = dataGridViewCellStyle4;
            this.WartoscVATa.HeaderText = "Wartość VAT";
            this.WartoscVATa.Name = "WartoscVATa";
            this.WartoscVATa.ReadOnly = true;
            this.WartoscVATa.Width = 70;
            // 
            // WartoscBruttoa
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "C2";
            dataGridViewCellStyle5.NullValue = null;
            this.WartoscBruttoa.DefaultCellStyle = dataGridViewCellStyle5;
            this.WartoscBruttoa.HeaderText = "Wartość Brutto";
            this.WartoscBruttoa.Name = "WartoscBruttoa";
            this.WartoscBruttoa.ReadOnly = true;
            this.WartoscBruttoa.Width = 70;
            // 
            // lblNumerFaktury
            // 
            this.lblNumerFaktury.AutoSize = true;
            this.lblNumerFaktury.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNumerFaktury.Location = new System.Drawing.Point(333, 44);
            this.lblNumerFaktury.Name = "lblNumerFaktury";
            this.lblNumerFaktury.Size = new System.Drawing.Size(0, 18);
            this.lblNumerFaktury.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(322, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "Faktura";
            // 
            // labelDataWystawienia
            // 
            this.labelDataWystawienia.AutoSize = true;
            this.labelDataWystawienia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelDataWystawienia.Location = new System.Drawing.Point(653, 39);
            this.labelDataWystawienia.Name = "labelDataWystawienia";
            this.labelDataWystawienia.Size = new System.Drawing.Size(80, 18);
            this.labelDataWystawienia.TabIndex = 8;
            this.labelDataWystawienia.Text = "12.07.2020";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(609, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 18);
            this.label6.TabIndex = 7;
            this.label6.Text = "Data wystawienia:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.YellowGreen;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Lp,
            this.Nazwa,
            this.Jm,
            this.Ilosc,
            this.CenaNetto,
            this.Vat,
            this.WartoscNetto,
            this.WartoscVAT,
            this.WartoscBrutto});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(52, 223);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.Size = new System.Drawing.Size(681, 161);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
            // 
            // Lp
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Lp.DefaultCellStyle = dataGridViewCellStyle8;
            this.Lp.HeaderText = "Lp.";
            this.Lp.Name = "Lp";
            this.Lp.ReadOnly = true;
            this.Lp.Width = 20;
            // 
            // Nazwa
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.Nazwa.DefaultCellStyle = dataGridViewCellStyle9;
            this.Nazwa.HeaderText = "Nazwa Towaru";
            this.Nazwa.Name = "Nazwa";
            this.Nazwa.ReadOnly = true;
            this.Nazwa.Width = 250;
            // 
            // Jm
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Jm.DefaultCellStyle = dataGridViewCellStyle10;
            this.Jm.HeaderText = "J.m.";
            this.Jm.Name = "Jm";
            this.Jm.ReadOnly = true;
            this.Jm.Width = 30;
            // 
            // Ilosc
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Ilosc.DefaultCellStyle = dataGridViewCellStyle11;
            this.Ilosc.HeaderText = "Ilość";
            this.Ilosc.Name = "Ilosc";
            this.Ilosc.ReadOnly = true;
            this.Ilosc.Width = 50;
            // 
            // CenaNetto
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "C2";
            dataGridViewCellStyle12.NullValue = null;
            this.CenaNetto.DefaultCellStyle = dataGridViewCellStyle12;
            this.CenaNetto.HeaderText = "Cena Netto";
            this.CenaNetto.Name = "CenaNetto";
            this.CenaNetto.ReadOnly = true;
            this.CenaNetto.Width = 70;
            // 
            // Vat
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Vat.DefaultCellStyle = dataGridViewCellStyle13;
            this.Vat.HeaderText = "Vat[%]";
            this.Vat.Name = "Vat";
            this.Vat.ReadOnly = true;
            this.Vat.Width = 50;
            // 
            // WartoscNetto
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "C2";
            dataGridViewCellStyle14.NullValue = null;
            this.WartoscNetto.DefaultCellStyle = dataGridViewCellStyle14;
            this.WartoscNetto.HeaderText = "Wartość Netto";
            this.WartoscNetto.Name = "WartoscNetto";
            this.WartoscNetto.ReadOnly = true;
            this.WartoscNetto.Width = 70;
            // 
            // WartoscVAT
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "C2";
            this.WartoscVAT.DefaultCellStyle = dataGridViewCellStyle15;
            this.WartoscVAT.HeaderText = "Wartosć VAT";
            this.WartoscVAT.Name = "WartoscVAT";
            this.WartoscVAT.ReadOnly = true;
            this.WartoscVAT.Width = 70;
            // 
            // WartoscBrutto
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "C2";
            dataGridViewCellStyle16.NullValue = null;
            this.WartoscBrutto.DefaultCellStyle = dataGridViewCellStyle16;
            this.WartoscBrutto.HeaderText = "Wartość Brutto";
            this.WartoscBrutto.Name = "WartoscBrutto";
            this.WartoscBrutto.ReadOnly = true;
            this.WartoscBrutto.Width = 70;
            // 
            // groupBoxNabywca
            // 
            this.groupBoxNabywca.Controls.Add(this.lblFNabywcaRegon);
            this.groupBoxNabywca.Controls.Add(this.lblFNabywcaNIP);
            this.groupBoxNabywca.Controls.Add(this.lblFNabywcaAdres2);
            this.groupBoxNabywca.Controls.Add(this.lblFNabywcaAdres1);
            this.groupBoxNabywca.Controls.Add(this.lblFNabywcaNazwa);
            this.groupBoxNabywca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBoxNabywca.Location = new System.Drawing.Point(373, 85);
            this.groupBoxNabywca.Name = "groupBoxNabywca";
            this.groupBoxNabywca.Size = new System.Drawing.Size(360, 132);
            this.groupBoxNabywca.TabIndex = 5;
            this.groupBoxNabywca.TabStop = false;
            this.groupBoxNabywca.Text = "Nabywca:";
            // 
            // lblFNabywcaRegon
            // 
            this.lblFNabywcaRegon.AutoSize = true;
            this.lblFNabywcaRegon.Location = new System.Drawing.Point(6, 94);
            this.lblFNabywcaRegon.Name = "lblFNabywcaRegon";
            this.lblFNabywcaRegon.Size = new System.Drawing.Size(44, 18);
            this.lblFNabywcaRegon.TabIndex = 4;
            this.lblFNabywcaRegon.Text = "====";
            // 
            // lblFNabywcaNIP
            // 
            this.lblFNabywcaNIP.AutoSize = true;
            this.lblFNabywcaNIP.Location = new System.Drawing.Point(6, 76);
            this.lblFNabywcaNIP.Name = "lblFNabywcaNIP";
            this.lblFNabywcaNIP.Size = new System.Drawing.Size(44, 18);
            this.lblFNabywcaNIP.TabIndex = 3;
            this.lblFNabywcaNIP.Text = "====";
            // 
            // lblFNabywcaAdres2
            // 
            this.lblFNabywcaAdres2.AutoSize = true;
            this.lblFNabywcaAdres2.Location = new System.Drawing.Point(6, 58);
            this.lblFNabywcaAdres2.Name = "lblFNabywcaAdres2";
            this.lblFNabywcaAdres2.Size = new System.Drawing.Size(44, 18);
            this.lblFNabywcaAdres2.TabIndex = 2;
            this.lblFNabywcaAdres2.Text = "====";
            // 
            // lblFNabywcaAdres1
            // 
            this.lblFNabywcaAdres1.AutoSize = true;
            this.lblFNabywcaAdres1.Location = new System.Drawing.Point(6, 40);
            this.lblFNabywcaAdres1.Name = "lblFNabywcaAdres1";
            this.lblFNabywcaAdres1.Size = new System.Drawing.Size(44, 18);
            this.lblFNabywcaAdres1.TabIndex = 1;
            this.lblFNabywcaAdres1.Text = "====";
            // 
            // lblFNabywcaNazwa
            // 
            this.lblFNabywcaNazwa.AutoSize = true;
            this.lblFNabywcaNazwa.Location = new System.Drawing.Point(6, 22);
            this.lblFNabywcaNazwa.Name = "lblFNabywcaNazwa";
            this.lblFNabywcaNazwa.Size = new System.Drawing.Size(44, 18);
            this.lblFNabywcaNazwa.TabIndex = 0;
            this.lblFNabywcaNazwa.Text = "====";
            // 
            // groupBoxNadawca
            // 
            this.groupBoxNadawca.Controls.Add(this.labelSprzedawcaREGON);
            this.groupBoxNadawca.Controls.Add(this.labelSprzedawcaNIP);
            this.groupBoxNadawca.Controls.Add(this.labelSprzedawcaAdres2);
            this.groupBoxNadawca.Controls.Add(this.labelSprzedawcaAdres1);
            this.groupBoxNadawca.Controls.Add(this.labelSprzedawcaNazwa);
            this.groupBoxNadawca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBoxNadawca.Location = new System.Drawing.Point(52, 85);
            this.groupBoxNadawca.Name = "groupBoxNadawca";
            this.groupBoxNadawca.Size = new System.Drawing.Size(315, 132);
            this.groupBoxNadawca.TabIndex = 0;
            this.groupBoxNadawca.TabStop = false;
            this.groupBoxNadawca.Text = "Sprzedawca:";
            // 
            // labelSprzedawcaREGON
            // 
            this.labelSprzedawcaREGON.AutoSize = true;
            this.labelSprzedawcaREGON.Location = new System.Drawing.Point(6, 96);
            this.labelSprzedawcaREGON.Name = "labelSprzedawcaREGON";
            this.labelSprzedawcaREGON.Size = new System.Drawing.Size(44, 18);
            this.labelSprzedawcaREGON.TabIndex = 4;
            this.labelSprzedawcaREGON.Text = "====";
            // 
            // labelSprzedawcaNIP
            // 
            this.labelSprzedawcaNIP.AutoSize = true;
            this.labelSprzedawcaNIP.Location = new System.Drawing.Point(6, 78);
            this.labelSprzedawcaNIP.Name = "labelSprzedawcaNIP";
            this.labelSprzedawcaNIP.Size = new System.Drawing.Size(44, 18);
            this.labelSprzedawcaNIP.TabIndex = 3;
            this.labelSprzedawcaNIP.Text = "====";
            // 
            // labelSprzedawcaAdres2
            // 
            this.labelSprzedawcaAdres2.AutoSize = true;
            this.labelSprzedawcaAdres2.Location = new System.Drawing.Point(6, 60);
            this.labelSprzedawcaAdres2.Name = "labelSprzedawcaAdres2";
            this.labelSprzedawcaAdres2.Size = new System.Drawing.Size(44, 18);
            this.labelSprzedawcaAdres2.TabIndex = 2;
            this.labelSprzedawcaAdres2.Text = "====";
            // 
            // labelSprzedawcaAdres1
            // 
            this.labelSprzedawcaAdres1.AutoSize = true;
            this.labelSprzedawcaAdres1.Location = new System.Drawing.Point(6, 42);
            this.labelSprzedawcaAdres1.Name = "labelSprzedawcaAdres1";
            this.labelSprzedawcaAdres1.Size = new System.Drawing.Size(44, 18);
            this.labelSprzedawcaAdres1.TabIndex = 1;
            this.labelSprzedawcaAdres1.Text = "====";
            // 
            // labelSprzedawcaNazwa
            // 
            this.labelSprzedawcaNazwa.AutoSize = true;
            this.labelSprzedawcaNazwa.Location = new System.Drawing.Point(6, 24);
            this.labelSprzedawcaNazwa.Name = "labelSprzedawcaNazwa";
            this.labelSprzedawcaNazwa.Size = new System.Drawing.Size(44, 18);
            this.labelSprzedawcaNazwa.TabIndex = 0;
            this.labelSprzedawcaNazwa.Text = "====";
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // groupBoxNabywcaSelect
            // 
            this.groupBoxNabywcaSelect.Controls.Add(this.btnNabywca);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblNabywcaRegon);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblNnabywcaNIP);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblNabywcaAdres2);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblNabywcaAdres1);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblNabywcaNazwa);
            this.groupBoxNabywcaSelect.Controls.Add(this.lblFOdbiorcyID);
            this.groupBoxNabywcaSelect.Controls.Add(this.labelCount);
            this.groupBoxNabywcaSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBoxNabywcaSelect.Location = new System.Drawing.Point(679, 37);
            this.groupBoxNabywcaSelect.Name = "groupBoxNabywcaSelect";
            this.groupBoxNabywcaSelect.Size = new System.Drawing.Size(270, 197);
            this.groupBoxNabywcaSelect.TabIndex = 12;
            this.groupBoxNabywcaSelect.TabStop = false;
            this.groupBoxNabywcaSelect.Text = "Nabywca:";
            // 
            // btnNabywca
            // 
            this.btnNabywca.BackColor = System.Drawing.Color.Transparent;
            this.btnNabywca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNabywca.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnNabywca.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnNabywca.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnNabywca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNabywca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnNabywca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnNabywca.Image = ((System.Drawing.Image)(resources.GetObject("btnNabywca.Image")));
            this.btnNabywca.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNabywca.Location = new System.Drawing.Point(21, 130);
            this.btnNabywca.Name = "btnNabywca";
            this.btnNabywca.Size = new System.Drawing.Size(150, 60);
            this.btnNabywca.TabIndex = 12;
            this.btnNabywca.Text = "Wybierz \r\nNabywcę";
            this.btnNabywca.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNabywca.UseVisualStyleBackColor = false;
            this.btnNabywca.Click += new System.EventHandler(this.btnNabywca_Click);
            // 
            // lblNabywcaRegon
            // 
            this.lblNabywcaRegon.AutoSize = true;
            this.lblNabywcaRegon.Location = new System.Drawing.Point(6, 94);
            this.lblNabywcaRegon.Name = "lblNabywcaRegon";
            this.lblNabywcaRegon.Size = new System.Drawing.Size(0, 18);
            this.lblNabywcaRegon.TabIndex = 4;
            // 
            // lblNnabywcaNIP
            // 
            this.lblNnabywcaNIP.AutoSize = true;
            this.lblNnabywcaNIP.Location = new System.Drawing.Point(6, 76);
            this.lblNnabywcaNIP.Name = "lblNnabywcaNIP";
            this.lblNnabywcaNIP.Size = new System.Drawing.Size(0, 18);
            this.lblNnabywcaNIP.TabIndex = 3;
            // 
            // lblNabywcaAdres2
            // 
            this.lblNabywcaAdres2.AutoSize = true;
            this.lblNabywcaAdres2.Location = new System.Drawing.Point(6, 58);
            this.lblNabywcaAdres2.Name = "lblNabywcaAdres2";
            this.lblNabywcaAdres2.Size = new System.Drawing.Size(0, 18);
            this.lblNabywcaAdres2.TabIndex = 2;
            // 
            // lblNabywcaAdres1
            // 
            this.lblNabywcaAdres1.AutoSize = true;
            this.lblNabywcaAdres1.Location = new System.Drawing.Point(6, 40);
            this.lblNabywcaAdres1.Name = "lblNabywcaAdres1";
            this.lblNabywcaAdres1.Size = new System.Drawing.Size(0, 18);
            this.lblNabywcaAdres1.TabIndex = 1;
            // 
            // lblNabywcaNazwa
            // 
            this.lblNabywcaNazwa.AutoSize = true;
            this.lblNabywcaNazwa.Location = new System.Drawing.Point(6, 22);
            this.lblNabywcaNazwa.Name = "lblNabywcaNazwa";
            this.lblNabywcaNazwa.Size = new System.Drawing.Size(0, 18);
            this.lblNabywcaNazwa.TabIndex = 0;
            // 
            // lblFOdbiorcyID
            // 
            this.lblFOdbiorcyID.AutoSize = true;
            this.lblFOdbiorcyID.Location = new System.Drawing.Point(42, 159);
            this.lblFOdbiorcyID.Name = "lblFOdbiorcyID";
            this.lblFOdbiorcyID.Size = new System.Drawing.Size(46, 18);
            this.lblFOdbiorcyID.TabIndex = 67;
            this.lblFOdbiorcyID.Text = "label1";
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(26, 141);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(54, 18);
            this.labelCount.TabIndex = 83;
            this.labelCount.Text = "label15";
            // 
            // btnDodajProdukt
            // 
            this.btnDodajProdukt.BackColor = System.Drawing.Color.Transparent;
            this.btnDodajProdukt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDodajProdukt.Enabled = false;
            this.btnDodajProdukt.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnDodajProdukt.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnDodajProdukt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnDodajProdukt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodajProdukt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDodajProdukt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnDodajProdukt.Image = ((System.Drawing.Image)(resources.GetObject("btnDodajProdukt.Image")));
            this.btnDodajProdukt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDodajProdukt.Location = new System.Drawing.Point(496, 332);
            this.btnDodajProdukt.Name = "btnDodajProdukt";
            this.btnDodajProdukt.Size = new System.Drawing.Size(150, 60);
            this.btnDodajProdukt.TabIndex = 14;
            this.btnDodajProdukt.Text = "Dodaj \r\nProdukt";
            this.btnDodajProdukt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDodajProdukt.UseVisualStyleBackColor = false;
            this.btnDodajProdukt.Click += new System.EventHandler(this.btnDodajProdukt_Click);
            // 
            // textBoxIlosc
            // 
            this.textBoxIlosc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxIlosc.Location = new System.Drawing.Point(417, 356);
            this.textBoxIlosc.Name = "textBoxIlosc";
            this.textBoxIlosc.Size = new System.Drawing.Size(68, 29);
            this.textBoxIlosc.TabIndex = 73;
            this.textBoxIlosc.TextChanged += new System.EventHandler(this.textBoxIlosc_TextChanged);
            this.textBoxIlosc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxIlosc_KeyPress);
            // 
            // lblNazwa
            // 
            this.lblNazwa.AutoSize = true;
            this.lblNazwa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNazwa.Location = new System.Drawing.Point(5, 337);
            this.lblNazwa.Name = "lblNazwa";
            this.lblNazwa.Size = new System.Drawing.Size(22, 16);
            this.lblNazwa.TabIndex = 71;
            this.lblNazwa.Text = "==";
            // 
            // txtNazwaFilter
            // 
            this.txtNazwaFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNazwaFilter.Location = new System.Drawing.Point(28, 6);
            this.txtNazwaFilter.MaxLength = 22;
            this.txtNazwaFilter.Name = "txtNazwaFilter";
            this.txtNazwaFilter.Size = new System.Drawing.Size(401, 22);
            this.txtNazwaFilter.TabIndex = 70;
            this.txtNazwaFilter.TextChanged += new System.EventHandler(this.txtNazwaFilter_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridView2.ColumnHeadersHeight = 22;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.Arrow;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridView2.Location = new System.Drawing.Point(8, 27);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridView2.RowHeadersWidth = 20;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(638, 299);
            this.dataGridView2.TabIndex = 69;
            this.dataGridView2.TabStop = false;
            this.dataGridView2.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEnter);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridView3.ColumnHeadersHeight = 22;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NazwaX,
            this.CenaX,
            this.VatX,
            this.IloscX,
            this.UsunX});
            this.dataGridView3.Cursor = System.Windows.Forms.Cursors.Arrow;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridView3.EnableHeadersVisualStyles = false;
            this.dataGridView3.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridView3.Location = new System.Drawing.Point(8, 398);
            this.dataGridView3.MultiSelect = false;
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridView3.RowHeadersWidth = 20;
            this.dataGridView3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridView3.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(842, 185);
            this.dataGridView3.TabIndex = 75;
            this.dataGridView3.TabStop = false;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // NazwaX
            // 
            this.NazwaX.HeaderText = "Nazwa";
            this.NazwaX.Name = "NazwaX";
            this.NazwaX.ReadOnly = true;
            this.NazwaX.Width = 400;
            // 
            // CenaX
            // 
            this.CenaX.HeaderText = "Cena";
            this.CenaX.Name = "CenaX";
            this.CenaX.ReadOnly = true;
            // 
            // VatX
            // 
            this.VatX.HeaderText = "Vat";
            this.VatX.Name = "VatX";
            this.VatX.ReadOnly = true;
            // 
            // IloscX
            // 
            this.IloscX.HeaderText = "Ilość";
            this.IloscX.Name = "IloscX";
            this.IloscX.ReadOnly = true;
            // 
            // UsunX
            // 
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle25.NullValue = "Usuń";
            this.UsunX.DefaultCellStyle = dataGridViewCellStyle25;
            this.UsunX.HeaderText = "Usuń";
            this.UsunX.Name = "UsunX";
            this.UsunX.ReadOnly = true;
            // 
            // btnZapisz
            // 
            this.btnZapisz.BackColor = System.Drawing.Color.Transparent;
            this.btnZapisz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapisz.Enabled = false;
            this.btnZapisz.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZapisz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZapisz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZapisz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapisz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZapisz.Image = ((System.Drawing.Image)(resources.GetObject("btnZapisz.Image")));
            this.btnZapisz.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZapisz.Location = new System.Drawing.Point(856, 398);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(150, 60);
            this.btnZapisz.TabIndex = 76;
            this.btnZapisz.Text = "Utwórz \r\nFakturę";
            this.btnZapisz.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZapisz.UseVisualStyleBackColor = false;
            this.btnZapisz.Click += new System.EventHandler(this.btnZapisz_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.dateTimePicker1.Location = new System.Drawing.Point(679, 264);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(270, 22);
            this.dateTimePicker1.TabIndex = 77;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(676, 245);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 16);
            this.label13.TabIndex = 78;
            this.label13.Text = "Termin płatności:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(679, 302);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 16);
            this.label14.TabIndex = 79;
            this.label14.Text = "Forma płatności:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton1.Location = new System.Drawing.Point(682, 321);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(72, 20);
            this.radioButton1.TabIndex = 80;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "przelew";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton2.Location = new System.Drawing.Point(682, 347);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(77, 20);
            this.radioButton2.TabIndex = 81;
            this.radioButton2.Text = "gotówka";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // UCUtworzFakture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnZapisz);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.textBoxIlosc);
            this.Controls.Add(this.lblNazwa);
            this.Controls.Add(this.txtNazwaFilter);
            this.Controls.Add(this.panelFaktura);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnDodajProdukt);
            this.Controls.Add(this.groupBoxNabywcaSelect);
            this.Name = "UCUtworzFakture";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(1091, 591);
            this.Load += new System.EventHandler(this.UCUtworzFakture_Load);
            this.panelFaktura.ResumeLayout(false);
            this.panelFaktura.PerformLayout();
            this.panelpodsumowanie.ResumeLayout(false);
            this.panelpodsumowanie.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBoxNabywca.ResumeLayout(false);
            this.groupBoxNabywca.PerformLayout();
            this.groupBoxNadawca.ResumeLayout(false);
            this.groupBoxNadawca.PerformLayout();
            this.groupBoxNabywcaSelect.ResumeLayout(false);
            this.groupBoxNabywcaSelect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelFaktura;
        private System.Windows.Forms.GroupBox groupBoxNadawca;
        private System.Windows.Forms.Label labelSprzedawcaREGON;
        private System.Windows.Forms.Label labelSprzedawcaNIP;
        private System.Windows.Forms.Label labelSprzedawcaAdres2;
        private System.Windows.Forms.Label labelSprzedawcaAdres1;
        private System.Windows.Forms.Label labelSprzedawcaNazwa;
        private System.Windows.Forms.GroupBox groupBoxNabywca;
        private System.Windows.Forms.Label lblFNabywcaRegon;
        private System.Windows.Forms.Label lblFNabywcaNIP;
        private System.Windows.Forms.Label lblFNabywcaAdres2;
        private System.Windows.Forms.Label lblFNabywcaAdres1;
        private System.Windows.Forms.Label lblFNabywcaNazwa;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelDataWystawienia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblNumerFaktury;
        private System.Windows.Forms.GroupBox groupBoxNabywcaSelect;
        private System.Windows.Forms.Label lblNabywcaRegon;
        private System.Windows.Forms.Label lblNnabywcaNIP;
        private System.Windows.Forms.Label lblNabywcaAdres2;
        private System.Windows.Forms.Label lblNabywcaAdres1;
        private System.Windows.Forms.Label lblNabywcaNazwa;
        private System.Windows.Forms.Button btnNabywca;
        private System.Windows.Forms.Button btnDodajProdukt;
        private System.Windows.Forms.TextBox textBoxIlosc;
        private System.Windows.Forms.Label lblNazwa;
        private System.Windows.Forms.TextBox txtNazwaFilter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.Label lblFOdbiorcyID;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lp;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nazwa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Jm;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ilosc;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaNetto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vat;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscNetto;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscVAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscBrutto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Razema;
        private System.Windows.Forms.DataGridViewTextBoxColumn VATa;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscNettoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscVATa;
        private System.Windows.Forms.DataGridViewTextBoxColumn WartoscBruttoa;
        private System.Windows.Forms.Panel panelpodsumowanie;
        private System.Windows.Forms.Label labelNrKonta;
        private System.Windows.Forms.Label labelTermin;
        private System.Windows.Forms.Label labelForma;
        private System.Windows.Forms.Label labelDozaplaty;
        private System.Windows.Forms.Label labelRazem;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn NazwaX;
        private System.Windows.Forms.DataGridViewTextBoxColumn CenaX;
        private System.Windows.Forms.DataGridViewTextBoxColumn VatX;
        private System.Windows.Forms.DataGridViewTextBoxColumn IloscX;
        private System.Windows.Forms.DataGridViewButtonColumn UsunX;
    }
}
