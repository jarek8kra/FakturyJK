﻿namespace Faktury_JK
{
    partial class UCNadawca
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label REGONlabel;
            System.Windows.Forms.Label nazwaLabel;
            System.Windows.Forms.Label UlicaNumerLabel;
            System.Windows.Forms.Label KodMiejscowoscLabel;
            System.Windows.Forms.Label NIPLabel;
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCNadawca));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOdswiez = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnEdytuj = new System.Windows.Forms.Button();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.uzytkownicyIDLabel1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.NrKontatextBox = new System.Windows.Forms.TextBox();
            this.NIPtextBox = new System.Windows.Forms.TextBox();
            this.REGONtextBox = new System.Windows.Forms.TextBox();
            this.NazwaTextBox = new System.Windows.Forms.TextBox();
            this.UlNumerTextBox = new System.Windows.Forms.TextBox();
            this.KodMiejscowoscTextBox = new System.Windows.Forms.TextBox();
            REGONlabel = new System.Windows.Forms.Label();
            nazwaLabel = new System.Windows.Forms.Label();
            UlicaNumerLabel = new System.Windows.Forms.Label();
            KodMiejscowoscLabel = new System.Windows.Forms.Label();
            NIPLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // REGONlabel
            // 
            REGONlabel.AutoSize = true;
            REGONlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            REGONlabel.Location = new System.Drawing.Point(89, 183);
            REGONlabel.Name = "REGONlabel";
            REGONlabel.Size = new System.Drawing.Size(60, 16);
            REGONlabel.TabIndex = 78;
            REGONlabel.Text = "REGON:";
            // 
            // nazwaLabel
            // 
            nazwaLabel.AutoSize = true;
            nazwaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            nazwaLabel.Location = new System.Drawing.Point(39, 68);
            nazwaLabel.Name = "nazwaLabel";
            nazwaLabel.Size = new System.Drawing.Size(112, 16);
            nazwaLabel.TabIndex = 74;
            nazwaLabel.Text = "Nazwa Nadawcy:";
            // 
            // UlicaNumerLabel
            // 
            UlicaNumerLabel.AutoSize = true;
            UlicaNumerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            UlicaNumerLabel.Location = new System.Drawing.Point(90, 96);
            UlicaNumerLabel.Name = "UlicaNumerLabel";
            UlicaNumerLabel.Size = new System.Drawing.Size(59, 16);
            UlicaNumerLabel.TabIndex = 75;
            UlicaNumerLabel.Text = "Ulica, nr:";
            // 
            // KodMiejscowoscLabel
            // 
            KodMiejscowoscLabel.AutoSize = true;
            KodMiejscowoscLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            KodMiejscowoscLabel.Location = new System.Drawing.Point(30, 124);
            KodMiejscowoscLabel.Name = "KodMiejscowoscLabel";
            KodMiejscowoscLabel.Size = new System.Drawing.Size(119, 16);
            KodMiejscowoscLabel.TabIndex = 76;
            KodMiejscowoscLabel.Text = "Kod, Miejscowość:";
            // 
            // NIPLabel
            // 
            NIPLabel.AutoSize = true;
            NIPLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            NIPLabel.Location = new System.Drawing.Point(116, 155);
            NIPLabel.Name = "NIPLabel";
            NIPLabel.Size = new System.Drawing.Size(33, 16);
            NIPLabel.TabIndex = 77;
            NIPLabel.Text = "NIP:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label1.Location = new System.Drawing.Point(89, 213);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(64, 16);
            label1.TabIndex = 80;
            label1.Text = "Nr. konta:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnOdswiez);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnEdytuj);
            this.panel1.Controls.Add(this.btnDodaj);
            this.panel1.Controls.Add(this.uzytkownicyIDLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 604);
            this.panel1.TabIndex = 54;
            // 
            // btnOdswiez
            // 
            this.btnOdswiez.BackColor = System.Drawing.Color.Transparent;
            this.btnOdswiez.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOdswiez.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnOdswiez.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnOdswiez.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnOdswiez.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOdswiez.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOdswiez.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnOdswiez.Image = ((System.Drawing.Image)(resources.GetObject("btnOdswiez.Image")));
            this.btnOdswiez.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOdswiez.Location = new System.Drawing.Point(25, 220);
            this.btnOdswiez.Name = "btnOdswiez";
            this.btnOdswiez.Size = new System.Drawing.Size(150, 60);
            this.btnOdswiez.TabIndex = 52;
            this.btnOdswiez.Text = "Odśwież    ";
            this.btnOdswiez.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOdswiez.UseVisualStyleBackColor = false;
            this.btnOdswiez.Click += new System.EventHandler(this.btnOdswiez_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(21, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 20);
            this.label3.TabIndex = 50;
            this.label3.Text = "Nadawca:";
            // 
            // btnEdytuj
            // 
            this.btnEdytuj.BackColor = System.Drawing.Color.Transparent;
            this.btnEdytuj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdytuj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEdytuj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnEdytuj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnEdytuj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdytuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnEdytuj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnEdytuj.Image = ((System.Drawing.Image)(resources.GetObject("btnEdytuj.Image")));
            this.btnEdytuj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdytuj.Location = new System.Drawing.Point(25, 142);
            this.btnEdytuj.Name = "btnEdytuj";
            this.btnEdytuj.Size = new System.Drawing.Size(150, 60);
            this.btnEdytuj.TabIndex = 2;
            this.btnEdytuj.Text = "Edytuj  ";
            this.btnEdytuj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdytuj.UseVisualStyleBackColor = false;
            this.btnEdytuj.Click += new System.EventHandler(this.btnEdytuj_Click);
            // 
            // btnDodaj
            // 
            this.btnDodaj.BackColor = System.Drawing.Color.Transparent;
            this.btnDodaj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDodaj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnDodaj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnDodaj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnDodaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDodaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDodaj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnDodaj.Image = ((System.Drawing.Image)(resources.GetObject("btnDodaj.Image")));
            this.btnDodaj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDodaj.Location = new System.Drawing.Point(25, 64);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(150, 60);
            this.btnDodaj.TabIndex = 1;
            this.btnDodaj.Text = "Dodaj    ";
            this.btnDodaj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDodaj.UseVisualStyleBackColor = false;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // uzytkownicyIDLabel1
            // 
            this.uzytkownicyIDLabel1.Location = new System.Drawing.Point(128, -32);
            this.uzytkownicyIDLabel1.Name = "uzytkownicyIDLabel1";
            this.uzytkownicyIDLabel1.Size = new System.Drawing.Size(47, 23);
            this.uzytkownicyIDLabel1.TabIndex = 51;
            this.uzytkownicyIDLabel1.Text = "label2";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.NrKontatextBox);
            this.panel2.Controls.Add(label1);
            this.panel2.Controls.Add(this.NIPtextBox);
            this.panel2.Controls.Add(this.REGONtextBox);
            this.panel2.Controls.Add(REGONlabel);
            this.panel2.Controls.Add(nazwaLabel);
            this.panel2.Controls.Add(this.NazwaTextBox);
            this.panel2.Controls.Add(UlicaNumerLabel);
            this.panel2.Controls.Add(this.UlNumerTextBox);
            this.panel2.Controls.Add(KodMiejscowoscLabel);
            this.panel2.Controls.Add(this.KodMiejscowoscTextBox);
            this.panel2.Controls.Add(NIPLabel);
            this.panel2.Location = new System.Drawing.Point(210, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(432, 602);
            this.panel2.TabIndex = 69;
            // 
            // NrKontatextBox
            // 
            this.NrKontatextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NrKontatextBox.Location = new System.Drawing.Point(155, 210);
            this.NrKontatextBox.MaxLength = 26;
            this.NrKontatextBox.Name = "NrKontatextBox";
            this.NrKontatextBox.ReadOnly = true;
            this.NrKontatextBox.Size = new System.Drawing.Size(189, 22);
            this.NrKontatextBox.TabIndex = 79;
            // 
            // NIPtextBox
            // 
            this.NIPtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NIPtextBox.Location = new System.Drawing.Point(155, 152);
            this.NIPtextBox.MaxLength = 50;
            this.NIPtextBox.Name = "NIPtextBox";
            this.NIPtextBox.ReadOnly = true;
            this.NIPtextBox.Size = new System.Drawing.Size(131, 22);
            this.NIPtextBox.TabIndex = 72;
            // 
            // REGONtextBox
            // 
            this.REGONtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.REGONtextBox.Location = new System.Drawing.Point(155, 180);
            this.REGONtextBox.MaxLength = 50;
            this.REGONtextBox.Name = "REGONtextBox";
            this.REGONtextBox.ReadOnly = true;
            this.REGONtextBox.Size = new System.Drawing.Size(131, 22);
            this.REGONtextBox.TabIndex = 73;
            // 
            // NazwaTextBox
            // 
            this.NazwaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NazwaTextBox.Location = new System.Drawing.Point(155, 65);
            this.NazwaTextBox.MaxLength = 50;
            this.NazwaTextBox.Name = "NazwaTextBox";
            this.NazwaTextBox.ReadOnly = true;
            this.NazwaTextBox.Size = new System.Drawing.Size(189, 22);
            this.NazwaTextBox.TabIndex = 69;
            // 
            // UlNumerTextBox
            // 
            this.UlNumerTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.UlNumerTextBox.Location = new System.Drawing.Point(155, 93);
            this.UlNumerTextBox.MaxLength = 50;
            this.UlNumerTextBox.Name = "UlNumerTextBox";
            this.UlNumerTextBox.ReadOnly = true;
            this.UlNumerTextBox.Size = new System.Drawing.Size(189, 22);
            this.UlNumerTextBox.TabIndex = 70;
            // 
            // KodMiejscowoscTextBox
            // 
            this.KodMiejscowoscTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.KodMiejscowoscTextBox.Location = new System.Drawing.Point(155, 121);
            this.KodMiejscowoscTextBox.MaxLength = 50;
            this.KodMiejscowoscTextBox.Name = "KodMiejscowoscTextBox";
            this.KodMiejscowoscTextBox.ReadOnly = true;
            this.KodMiejscowoscTextBox.Size = new System.Drawing.Size(189, 22);
            this.KodMiejscowoscTextBox.TabIndex = 71;
            // 
            // UCNadawca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "UCNadawca";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(1160, 614);
            this.Load += new System.EventHandler(this.UCNadawca_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnEdytuj;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Label uzytkownicyIDLabel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox NIPtextBox;
        private System.Windows.Forms.TextBox REGONtextBox;
        private System.Windows.Forms.TextBox NazwaTextBox;
        private System.Windows.Forms.TextBox UlNumerTextBox;
        private System.Windows.Forms.TextBox KodMiejscowoscTextBox;
        private System.Windows.Forms.Button btnOdswiez;
        private System.Windows.Forms.TextBox NrKontatextBox;
    }
}
