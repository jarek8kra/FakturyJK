﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Faktury_JK
{
    public partial class FOdbiorcyDodaj : Form
    {
        public FOdbiorcyDodaj()
        {
            InitializeComponent();
        }
        void Sprawdzanie()
        {
            if(NazwaTextBox.Text!=string.Empty&&
                UlNumerTextBox.Text!=string.Empty&&
                KodMiejscowoscTextBox.Text != string.Empty &&
                NIPtextBox.Text != string.Empty &&
                REGONtextBox.Text != string.Empty&&
                EmailtextBox.Text!=string.Empty)
            {
                btnZapisz.Enabled = true;
            }
            else
            {
                btnZapisz.Enabled = false;
            }
        }

        private void NazwaTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void UlNumerTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void KodMiejscowoscTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }
        private void NIPtextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void REGONtextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }
        private void EmailtextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }
        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("AddOdbiorcy", con);

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@nazwa", SqlDbType.VarChar).Value = NazwaTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@adresun", SqlDbType.VarChar).Value = UlNumerTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@adreskm", SqlDbType.VarChar).Value = KodMiejscowoscTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@nip", SqlDbType.VarChar).Value = NIPtextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@regon", SqlDbType.VarChar).Value = REGONtextBox.Text.Trim();
            cmd.Parameters.AddWithValue("email", SqlDbType.VarChar).Value = EmailtextBox.Text.Trim();
            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }


    }
}
