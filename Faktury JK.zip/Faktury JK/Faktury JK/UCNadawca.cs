﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Faktury_JK
{
    public partial class UCNadawca : UserControl
    {
        public UCNadawca()
        {
            InitializeComponent();
        }
        private static UCNadawca _instance;
        public static UCNadawca Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCNadawca();
                return _instance;
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            FNadawcaDodaj fnd = new FNadawcaDodaj();
            DialogResult result = fnd.ShowDialog();
            Odswiezanie();

        }

        private void UCNadawca_Load(object sender, EventArgs e)
        {
            Odswiezanie();
            Sprawdzanie();
        }
        void Sprawdzanie()
        {
            if (NazwaTextBox.Text != string.Empty &&
    UlNumerTextBox.Text != string.Empty &&
    KodMiejscowoscTextBox.Text != string.Empty &&
    NIPtextBox.Text != string.Empty &&
    REGONtextBox.Text != string.Empty)
            {
                btnDodaj.Enabled = false;
                btnEdytuj.Enabled = true;
            }
            else
            {
                btnDodaj.Enabled = true;
                btnEdytuj.Enabled = false;
            }
        }
        void Odswiezanie()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("NadawcaView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            NazwaTextBox.DataBindings.Clear();
            NazwaTextBox.DataBindings.Add("Text", dt, "Nazwa");
            UlNumerTextBox.DataBindings.Clear();
            UlNumerTextBox.DataBindings.Add("Text", dt, "AdresUlicaNumer");
            KodMiejscowoscTextBox.DataBindings.Clear();
            KodMiejscowoscTextBox.DataBindings.Add("Text", dt, "AdresKodMiasto");
            NIPtextBox.DataBindings.Clear();
            NIPtextBox.DataBindings.Add("Text", dt, "NIP");
            REGONtextBox.DataBindings.Clear();
            REGONtextBox.DataBindings.Add("Text", dt, "REGON");
            NrKontatextBox.DataBindings.Clear();
            NrKontatextBox.DataBindings.Add("Text", dt, "NrKonta");
            con.Close();

            Sprawdzanie();
        }

        private void btnOdswiez_Click(object sender, EventArgs e)
        {
           // Odswiezanie();
        }

        private void btnEdytuj_Click(object sender, EventArgs e)
        {
            FNadawcaEdytuj fne = new FNadawcaEdytuj();
            DialogResult result = fne.ShowDialog();
            Odswiezanie();
        }

    }
}
