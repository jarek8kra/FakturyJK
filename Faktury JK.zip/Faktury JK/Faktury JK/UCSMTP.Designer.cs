﻿namespace Faktury_JK
{
    partial class UCSMTP
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCSMTP));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelIDOdbiorcyView = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnOdswiez = new System.Windows.Forms.Button();
            this.btnPodgląd = new System.Windows.Forms.Button();
            this.btnEmail = new System.Windows.Forms.Button();
            this.uzytkownicyIDLabel1 = new System.Windows.Forms.Label();
            this.txtnazwaOdbiorcyFilter = new System.Windows.Forms.TextBox();
            this.txtDataWystFilter = new System.Windows.Forms.TextBox();
            this.txtNrfakturyFilter = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelIDOdbiorcy = new System.Windows.Forms.Label();
            this.labelEmailOdbiorcy = new System.Windows.Forms.Label();
            this.labelNrFaktury = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItemEmail = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemPodgląd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemodswiez = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.labelIDOdbiorcyView);
            this.panel1.Controls.Add(this.lblCount);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnOdswiez);
            this.panel1.Controls.Add(this.btnPodgląd);
            this.panel1.Controls.Add(this.btnEmail);
            this.panel1.Controls.Add(this.uzytkownicyIDLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 620);
            this.panel1.TabIndex = 60;
            // 
            // labelIDOdbiorcyView
            // 
            this.labelIDOdbiorcyView.AutoSize = true;
            this.labelIDOdbiorcyView.Location = new System.Drawing.Point(-20, -20);
            this.labelIDOdbiorcyView.Name = "labelIDOdbiorcyView";
            this.labelIDOdbiorcyView.Size = new System.Drawing.Size(35, 13);
            this.labelIDOdbiorcyView.TabIndex = 54;
            this.labelIDOdbiorcyView.Text = "label1";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.BackColor = System.Drawing.Color.Transparent;
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblCount.ForeColor = System.Drawing.Color.Black;
            this.lblCount.Location = new System.Drawing.Point(95, 298);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(19, 20);
            this.lblCount.TabIndex = 53;
            this.lblCount.Text = "--";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(21, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 52;
            this.label2.Text = "Wpisów:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(21, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 50;
            this.label3.Text = "Historia";
            // 
            // btnOdswiez
            // 
            this.btnOdswiez.BackColor = System.Drawing.Color.Transparent;
            this.btnOdswiez.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOdswiez.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnOdswiez.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnOdswiez.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnOdswiez.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOdswiez.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOdswiez.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnOdswiez.Image = ((System.Drawing.Image)(resources.GetObject("btnOdswiez.Image")));
            this.btnOdswiez.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOdswiez.Location = new System.Drawing.Point(25, 219);
            this.btnOdswiez.Name = "btnOdswiez";
            this.btnOdswiez.Size = new System.Drawing.Size(150, 60);
            this.btnOdswiez.TabIndex = 4;
            this.btnOdswiez.Text = "Odśwież    ";
            this.btnOdswiez.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOdswiez.UseVisualStyleBackColor = false;
            this.btnOdswiez.Click += new System.EventHandler(this.btnOdswiez_Click);
            // 
            // btnPodgląd
            // 
            this.btnPodgląd.BackColor = System.Drawing.Color.Transparent;
            this.btnPodgląd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPodgląd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPodgląd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnPodgląd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnPodgląd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPodgląd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPodgląd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnPodgląd.Image = ((System.Drawing.Image)(resources.GetObject("btnPodgląd.Image")));
            this.btnPodgląd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPodgląd.Location = new System.Drawing.Point(25, 142);
            this.btnPodgląd.Name = "btnPodgląd";
            this.btnPodgląd.Size = new System.Drawing.Size(150, 60);
            this.btnPodgląd.TabIndex = 2;
            this.btnPodgląd.Text = "Podgląd ";
            this.btnPodgląd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPodgląd.UseVisualStyleBackColor = false;
            this.btnPodgląd.Click += new System.EventHandler(this.btnPodgląd_Click);
            // 
            // btnEmail
            // 
            this.btnEmail.BackColor = System.Drawing.Color.Transparent;
            this.btnEmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmail.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEmail.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnEmail.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnEmail.Image = ((System.Drawing.Image)(resources.GetObject("btnEmail.Image")));
            this.btnEmail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmail.Location = new System.Drawing.Point(25, 64);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(150, 60);
            this.btnEmail.TabIndex = 1;
            this.btnEmail.Text = "Email     ";
            this.btnEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmail.UseVisualStyleBackColor = false;
            this.btnEmail.Click += new System.EventHandler(this.btnEmail_Click);
            // 
            // uzytkownicyIDLabel1
            // 
            this.uzytkownicyIDLabel1.Location = new System.Drawing.Point(128, -32);
            this.uzytkownicyIDLabel1.Name = "uzytkownicyIDLabel1";
            this.uzytkownicyIDLabel1.Size = new System.Drawing.Size(47, 23);
            this.uzytkownicyIDLabel1.TabIndex = 51;
            this.uzytkownicyIDLabel1.Text = "label2";
            // 
            // txtnazwaOdbiorcyFilter
            // 
            this.txtnazwaOdbiorcyFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtnazwaOdbiorcyFilter.Location = new System.Drawing.Point(451, 11);
            this.txtnazwaOdbiorcyFilter.MaxLength = 22;
            this.txtnazwaOdbiorcyFilter.Name = "txtnazwaOdbiorcyFilter";
            this.txtnazwaOdbiorcyFilter.Size = new System.Drawing.Size(161, 22);
            this.txtnazwaOdbiorcyFilter.TabIndex = 64;
            this.txtnazwaOdbiorcyFilter.TextChanged += new System.EventHandler(this.txtnazwaOdbiorcyFilter_TextChanged);
            this.txtnazwaOdbiorcyFilter.Enter += new System.EventHandler(this.txtnazwaOdbiorcyFilter_Enter);
            // 
            // txtDataWystFilter
            // 
            this.txtDataWystFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDataWystFilter.Location = new System.Drawing.Point(311, 11);
            this.txtDataWystFilter.MaxLength = 22;
            this.txtDataWystFilter.Name = "txtDataWystFilter";
            this.txtDataWystFilter.Size = new System.Drawing.Size(141, 22);
            this.txtDataWystFilter.TabIndex = 63;
            this.txtDataWystFilter.TextChanged += new System.EventHandler(this.txtDataWystFilter_TextChanged);
            this.txtDataWystFilter.Enter += new System.EventHandler(this.txtDataWystFilter_Enter);
            // 
            // txtNrfakturyFilter
            // 
            this.txtNrfakturyFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNrfakturyFilter.Location = new System.Drawing.Point(231, 11);
            this.txtNrfakturyFilter.MaxLength = 22;
            this.txtNrfakturyFilter.Name = "txtNrfakturyFilter";
            this.txtNrfakturyFilter.Size = new System.Drawing.Size(81, 22);
            this.txtNrfakturyFilter.TabIndex = 62;
            this.txtNrfakturyFilter.TextChanged += new System.EventHandler(this.txtNrfakturyFilter_TextChanged);
            this.txtNrfakturyFilter.Enter += new System.EventHandler(this.txtNrfakturyFilter_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeight = 22;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.Location = new System.Drawing.Point(211, 32);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DimGray;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(419, 593);
            this.dataGridView1.TabIndex = 61;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseDown);
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox1.Location = new System.Drawing.Point(636, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(515, 593);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 65;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Resize += new System.EventHandler(this.pictureBox1_Resize);
            // 
            // labelIDOdbiorcy
            // 
            this.labelIDOdbiorcy.AutoSize = true;
            this.labelIDOdbiorcy.Location = new System.Drawing.Point(-20, -20);
            this.labelIDOdbiorcy.Name = "labelIDOdbiorcy";
            this.labelIDOdbiorcy.Size = new System.Drawing.Size(82, 13);
            this.labelIDOdbiorcy.TabIndex = 66;
            this.labelIDOdbiorcy.Text = "labelIDOdbiorcy";
            // 
            // labelEmailOdbiorcy
            // 
            this.labelEmailOdbiorcy.AutoSize = true;
            this.labelEmailOdbiorcy.Location = new System.Drawing.Point(-20, -20);
            this.labelEmailOdbiorcy.Name = "labelEmailOdbiorcy";
            this.labelEmailOdbiorcy.Size = new System.Drawing.Size(35, 13);
            this.labelEmailOdbiorcy.TabIndex = 67;
            this.labelEmailOdbiorcy.Text = "label1";
            // 
            // labelNrFaktury
            // 
            this.labelNrFaktury.AutoSize = true;
            this.labelNrFaktury.Location = new System.Drawing.Point(-20, -20);
            this.labelNrFaktury.Name = "labelNrFaktury";
            this.labelNrFaktury.Size = new System.Drawing.Size(35, 13);
            this.labelNrFaktury.TabIndex = 68;
            this.labelNrFaktury.Text = "label1";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemEmail,
            this.toolStripMenuItemPodgląd,
            this.toolStripMenuItemodswiez});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(119, 70);
            // 
            // toolStripMenuItemEmail
            // 
            this.toolStripMenuItemEmail.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItemEmail.Image")));
            this.toolStripMenuItemEmail.Name = "toolStripMenuItemEmail";
            this.toolStripMenuItemEmail.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItemEmail.Text = "Email    ";
            this.toolStripMenuItemEmail.Click += new System.EventHandler(this.toolStripMenuItemEmail_Click);
            // 
            // toolStripMenuItemPodgląd
            // 
            this.toolStripMenuItemPodgląd.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItemPodgląd.Image")));
            this.toolStripMenuItemPodgląd.Name = "toolStripMenuItemPodgląd";
            this.toolStripMenuItemPodgląd.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItemPodgląd.Text = "Podgląd";
            this.toolStripMenuItemPodgląd.Click += new System.EventHandler(this.toolStripMenuItemPodgląd_Click);
            // 
            // toolStripMenuItemodswiez
            // 
            this.toolStripMenuItemodswiez.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItemodswiez.Image")));
            this.toolStripMenuItemodswiez.Name = "toolStripMenuItemodswiez";
            this.toolStripMenuItemodswiez.Size = new System.Drawing.Size(118, 22);
            this.toolStripMenuItemodswiez.Text = "Odśwież";
            this.toolStripMenuItemodswiez.Click += new System.EventHandler(this.toolStripMenuItemodswiez_Click);
            // 
            // UCSMTP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.Controls.Add(this.labelNrFaktury);
            this.Controls.Add(this.labelEmailOdbiorcy);
            this.Controls.Add(this.labelIDOdbiorcy);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtnazwaOdbiorcyFilter);
            this.Controls.Add(this.txtDataWystFilter);
            this.Controls.Add(this.txtNrfakturyFilter);
            this.Controls.Add(this.dataGridView1);
            this.Name = "UCSMTP";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(1180, 630);
            this.Load += new System.EventHandler(this.UCSMTP_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelIDOdbiorcyView;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnOdswiez;
        private System.Windows.Forms.Button btnPodgląd;
        private System.Windows.Forms.Button btnEmail;
        private System.Windows.Forms.Label uzytkownicyIDLabel1;
        private System.Windows.Forms.TextBox txtnazwaOdbiorcyFilter;
        private System.Windows.Forms.TextBox txtDataWystFilter;
        private System.Windows.Forms.TextBox txtNrfakturyFilter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelIDOdbiorcy;
        private System.Windows.Forms.Label labelEmailOdbiorcy;
        private System.Windows.Forms.Label labelNrFaktury;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemEmail;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemPodgląd;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemodswiez;
    }
}
