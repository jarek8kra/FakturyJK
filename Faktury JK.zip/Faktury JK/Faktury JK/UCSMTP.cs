﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
using System.Diagnostics;

namespace Faktury_JK
{
    public partial class UCSMTP : UserControl
    {
        public UCSMTP()
        {
            InitializeComponent();
        }
        private static UCSMTP _instance;
        public static UCSMTP Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCSMTP();
                return _instance;
            }
        }
        BindingSource bs;
        byte[] data;
        void Odswiezanie()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("FakturyView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            bs = new BindingSource();
            bs.DataSource = dt;
            dataGridView1.Columns["NrFaktury"].Width = 80;
            dataGridView1.Columns["NrFaktury"].HeaderText = "Nr Faktury";
            dataGridView1.Columns["DataWystawienia"].Width = 140;
            dataGridView1.Columns["DataWystawienia"].HeaderText = "Data Wystawienia";
            dataGridView1.Columns["Obraz"].Visible = false;
            dataGridView1.Columns["IdOdbiorcy"].Visible = false;
            dataGridView1.Columns["Nazwa"].Width = 160;
            dataGridView1.Columns["Nazwa"].HeaderText = "Nazwa Odbiorcy";
            dataGridView1.Columns["Email"].Visible = false;
            labelIDOdbiorcy.DataBindings.Clear();
            labelIDOdbiorcy.DataBindings.Add("Text", dt, "IdOdbiorcy");
            labelEmailOdbiorcy.DataBindings.Clear();
            labelEmailOdbiorcy.DataBindings.Add("Text", dt, "Email");
            labelNrFaktury.DataBindings.Clear();
            labelNrFaktury.DataBindings.Add("Text", dt, "NrFaktury");

            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    data = (byte[])dr.GetValue(2);//0
                                                  // name = (string)dr.GetValue(1);//1
                }
            }
            // label1.Text = name;
            pictureBox1.Image = Image.FromStream(new MemoryStream(data));
            con.Close();
            lblCount.Text = dataGridView1.Rows.Count.ToString();
        }
        void ZliczanieRekordow()
        {
            lblCount.Text = dataGridView1.Rows.Count.ToString();
        }

        private void UCSMTP_Load(object sender, EventArgs e)
        {
            Odswiezanie();
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            byte[] image = (byte[])dataGridView1.Rows[e.RowIndex].Cells[2].Value;
            MemoryStream ms = new MemoryStream(image);
            pictureBox1.Image = Image.FromStream(ms);
        }

        private void btnOdswiez_Click(object sender, EventArgs e)
        {
            Odswiezanie();
        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            pictureBox1.Width =  (Int32.Parse(pictureBox1.Height.ToString())*8)/10 ;
        }

        private void btnPodgląd_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            FUtworzFakturePreview fufp = new FUtworzFakturePreview(bmp);
            DialogResult result = fufp.ShowDialog(); 

        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            //int IDOdbiorcy = Int32.Parse(labelIDOdbiorcy.Text.ToString());
            Bitmap bmp = new Bitmap(pictureBox1.Image);
            string nrfaktury = labelNrFaktury.Text;
            string email = labelEmailOdbiorcy.Text;
            FSMTP fsmtp = new FSMTP(email,bmp,nrfaktury);
            fsmtp.ShowDialog();
        }

        private void toolStripMenuItemEmail_Click(object sender, EventArgs e)
        {
            btnEmail_Click(null, null);
        }

        private void toolStripMenuItemPodgląd_Click(object sender, EventArgs e)
        {
            btnPodgląd_Click(null, null);
        }

        private void toolStripMenuItemodswiez_Click(object sender, EventArgs e)
        {
            btnOdswiez_Click(null, null);
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                dataGridView1.Rows[e.RowIndex].Selected = true;
                dataGridView1.Focus();
            }
        }

        private void txtNrfakturyFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "NrFaktury";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNrfakturyFilter.Text);
            ZliczanieRekordow();
        }

        private void txtDataWystFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "DataWystawienia";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtDataWystFilter.Text);
            ZliczanieRekordow();
        }

        private void txtnazwaOdbiorcyFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Nazwa";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtnazwaOdbiorcyFilter.Text);
            ZliczanieRekordow();
        }

        private void txtNrfakturyFilter_Enter(object sender, EventArgs e)
        {
            //txtNrfakturyFilter.Text = string.Empty;
            txtDataWystFilter.Text = string.Empty;
            txtnazwaOdbiorcyFilter.Text = string.Empty;
        }

        private void txtDataWystFilter_Enter(object sender, EventArgs e)
        {
            txtNrfakturyFilter.Text = string.Empty;
           // txtDataWystFilter.Text = string.Empty;
            txtnazwaOdbiorcyFilter.Text = string.Empty;
        }

        private void txtnazwaOdbiorcyFilter_Enter(object sender, EventArgs e)
        {
            txtNrfakturyFilter.Text = string.Empty;
            txtDataWystFilter.Text = string.Empty;
           // txtnazwaOdbiorcyFilter.Text = string.Empty;
        }
    }
}
