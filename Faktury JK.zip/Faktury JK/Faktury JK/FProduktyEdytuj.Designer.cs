﻿namespace Faktury_JK
{
    partial class FProduktyEdytuj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label nazwaLabel;
            System.Windows.Forms.Label UlicaNumerLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FProduktyEdytuj));
            System.Windows.Forms.Label label1;
            this.NazwaProduktuTextBox = new System.Windows.Forms.TextBox();
            this.CenaTextBox = new System.Windows.Forms.TextBox();
            this.btnZapisz = new System.Windows.Forms.Button();
            this.btnAnuluj = new System.Windows.Forms.Button();
            this.labelIDProdukty = new System.Windows.Forms.Label();
            this.VattextBox = new System.Windows.Forms.TextBox();
            nazwaLabel = new System.Windows.Forms.Label();
            UlicaNumerLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nazwaLabel
            // 
            nazwaLabel.AutoSize = true;
            nazwaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            nazwaLabel.Location = new System.Drawing.Point(61, 41);
            nazwaLabel.Name = "nazwaLabel";
            nazwaLabel.Size = new System.Drawing.Size(107, 16);
            nazwaLabel.TabIndex = 72;
            nazwaLabel.Text = "Nazwa produktu:";
            // 
            // UlicaNumerLabel
            // 
            UlicaNumerLabel.AutoSize = true;
            UlicaNumerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            UlicaNumerLabel.Location = new System.Drawing.Point(61, 103);
            UlicaNumerLabel.Name = "UlicaNumerLabel";
            UlicaNumerLabel.Size = new System.Drawing.Size(43, 16);
            UlicaNumerLabel.TabIndex = 73;
            UlicaNumerLabel.Text = "Cena:";
            // 
            // NazwaProduktuTextBox
            // 
            this.NazwaProduktuTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NazwaProduktuTextBox.Location = new System.Drawing.Point(64, 60);
            this.NazwaProduktuTextBox.MaxLength = 50;
            this.NazwaProduktuTextBox.Name = "NazwaProduktuTextBox";
            this.NazwaProduktuTextBox.Size = new System.Drawing.Size(308, 22);
            this.NazwaProduktuTextBox.TabIndex = 0;
            this.NazwaProduktuTextBox.TextChanged += new System.EventHandler(this.NazwaProduktuTextBox_TextChanged);
            // 
            // CenaTextBox
            // 
            this.CenaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.CenaTextBox.Location = new System.Drawing.Point(113, 100);
            this.CenaTextBox.MaxLength = 50;
            this.CenaTextBox.Name = "CenaTextBox";
            this.CenaTextBox.Size = new System.Drawing.Size(101, 22);
            this.CenaTextBox.TabIndex = 1;
            this.CenaTextBox.TextChanged += new System.EventHandler(this.CenaTextBox_TextChanged);
            // 
            // btnZapisz
            // 
            this.btnZapisz.BackColor = System.Drawing.Color.Transparent;
            this.btnZapisz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapisz.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZapisz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZapisz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZapisz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapisz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZapisz.Image = ((System.Drawing.Image)(resources.GetObject("btnZapisz.Image")));
            this.btnZapisz.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZapisz.Location = new System.Drawing.Point(64, 157);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(150, 60);
            this.btnZapisz.TabIndex = 3;
            this.btnZapisz.Text = "Zapisz   ";
            this.btnZapisz.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZapisz.UseVisualStyleBackColor = false;
            this.btnZapisz.Click += new System.EventHandler(this.btnZapisz_Click);
            // 
            // btnAnuluj
            // 
            this.btnAnuluj.BackColor = System.Drawing.Color.Transparent;
            this.btnAnuluj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAnuluj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAnuluj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnAnuluj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnAnuluj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnuluj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAnuluj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAnuluj.Image = ((System.Drawing.Image)(resources.GetObject("btnAnuluj.Image")));
            this.btnAnuluj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnuluj.Location = new System.Drawing.Point(222, 157);
            this.btnAnuluj.Name = "btnAnuluj";
            this.btnAnuluj.Size = new System.Drawing.Size(150, 60);
            this.btnAnuluj.TabIndex = 4;
            this.btnAnuluj.Text = "Anuluj    ";
            this.btnAnuluj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAnuluj.UseVisualStyleBackColor = false;
            this.btnAnuluj.Click += new System.EventHandler(this.btnAnuluj_Click);
            // 
            // labelIDProdukty
            // 
            this.labelIDProdukty.AutoSize = true;
            this.labelIDProdukty.Location = new System.Drawing.Point(-20, -20);
            this.labelIDProdukty.Name = "labelIDProdukty";
            this.labelIDProdukty.Size = new System.Drawing.Size(35, 13);
            this.labelIDProdukty.TabIndex = 74;
            this.labelIDProdukty.Text = "label1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label1.Location = new System.Drawing.Point(218, 103);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(51, 16);
            label1.TabIndex = 76;
            label1.Text = "Vat[%]:";
            // 
            // VattextBox
            // 
            this.VattextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.VattextBox.Location = new System.Drawing.Point(271, 100);
            this.VattextBox.MaxLength = 50;
            this.VattextBox.Name = "VattextBox";
            this.VattextBox.Size = new System.Drawing.Size(101, 22);
            this.VattextBox.TabIndex = 2;
            this.VattextBox.TextChanged += new System.EventHandler(this.VattextBox_TextChanged);
            // 
            // FProduktyEdytuj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(434, 261);
            this.Controls.Add(label1);
            this.Controls.Add(this.VattextBox);
            this.Controls.Add(this.labelIDProdukty);
            this.Controls.Add(nazwaLabel);
            this.Controls.Add(this.NazwaProduktuTextBox);
            this.Controls.Add(UlicaNumerLabel);
            this.Controls.Add(this.CenaTextBox);
            this.Controls.Add(this.btnZapisz);
            this.Controls.Add(this.btnAnuluj);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FProduktyEdytuj";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Produkty/Edytuj";
            this.Load += new System.EventHandler(this.FProduktyEdytuj_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NazwaProduktuTextBox;
        private System.Windows.Forms.TextBox CenaTextBox;
        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.Button btnAnuluj;
        private System.Windows.Forms.Label labelIDProdukty;
        private System.Windows.Forms.TextBox VattextBox;
    }
}