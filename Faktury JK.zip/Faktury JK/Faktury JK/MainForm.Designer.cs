﻿namespace Faktury_JK
{
    partial class MainForm
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnMinimalizuj = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.lblNameUC = new System.Windows.Forms.Label();
            this.panelStatus = new System.Windows.Forms.Panel();
            this.panelBtnMenu = new System.Windows.Forms.Panel();
            this.btnUCUtworz = new System.Windows.Forms.Button();
            this.btnUCNadawca = new System.Windows.Forms.Button();
            this.btnUCProdukty = new System.Windows.Forms.Button();
            this.btnUCKonfiguracja = new System.Windows.Forms.Button();
            this.btnUCSMTP = new System.Windows.Forms.Button();
            this.btnUCOdbiorcy = new System.Windows.Forms.Button();
            this.panelUC = new System.Windows.Forms.Panel();
            this.btnAPI = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.panelBtnMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.White;
            this.panelMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMenu.Controls.Add(this.btnMinimalizuj);
            this.panelMenu.Controls.Add(this.btnZamknij);
            this.panelMenu.Controls.Add(this.btnMenu);
            this.panelMenu.Controls.Add(this.lblNameUC);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.panelMenu.Location = new System.Drawing.Point(5, 5);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1102, 70);
            this.panelMenu.TabIndex = 3;
            // 
            // btnMinimalizuj
            // 
            this.btnMinimalizuj.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimalizuj.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimalizuj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimalizuj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnMinimalizuj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnMinimalizuj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnMinimalizuj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimalizuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnMinimalizuj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnMinimalizuj.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimalizuj.Image")));
            this.btnMinimalizuj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMinimalizuj.Location = new System.Drawing.Point(789, 4);
            this.btnMinimalizuj.Name = "btnMinimalizuj";
            this.btnMinimalizuj.Size = new System.Drawing.Size(150, 60);
            this.btnMinimalizuj.TabIndex = 2;
            this.btnMinimalizuj.Text = "Minimalizuj";
            this.btnMinimalizuj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMinimalizuj.UseVisualStyleBackColor = false;
            this.btnMinimalizuj.Click += new System.EventHandler(this.btnMinimalizuj_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnZamknij.BackColor = System.Drawing.Color.Transparent;
            this.btnZamknij.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZamknij.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZamknij.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZamknij.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZamknij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZamknij.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZamknij.Image = ((System.Drawing.Image)(resources.GetObject("btnZamknij.Image")));
            this.btnZamknij.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZamknij.Location = new System.Drawing.Point(945, 4);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(150, 60);
            this.btnZamknij.TabIndex = 3;
            this.btnZamknij.Text = "Zamknij   ";
            this.btnZamknij.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.Transparent;
            this.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnMenu.Image")));
            this.btnMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenu.Location = new System.Drawing.Point(5, 4);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(150, 60);
            this.btnMenu.TabIndex = 0;
            this.btnMenu.Text = "Menu     ";
            this.btnMenu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // lblNameUC
            // 
            this.lblNameUC.AutoSize = true;
            this.lblNameUC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNameUC.ForeColor = System.Drawing.SystemColors.Desktop;
            this.lblNameUC.Location = new System.Drawing.Point(194, 19);
            this.lblNameUC.Name = "lblNameUC";
            this.lblNameUC.Size = new System.Drawing.Size(0, 25);
            this.lblNameUC.TabIndex = 17;
            // 
            // panelStatus
            // 
            this.panelStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelStatus.BackColor = System.Drawing.Color.White;
            this.panelStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStatus.Location = new System.Drawing.Point(5, 602);
            this.panelStatus.Name = "panelStatus";
            this.panelStatus.Size = new System.Drawing.Size(1102, 23);
            this.panelStatus.TabIndex = 29;
            // 
            // panelBtnMenu
            // 
            this.panelBtnMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelBtnMenu.BackColor = System.Drawing.Color.White;
            this.panelBtnMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelBtnMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBtnMenu.Controls.Add(this.btnAPI);
            this.panelBtnMenu.Controls.Add(this.btnUCUtworz);
            this.panelBtnMenu.Controls.Add(this.btnUCNadawca);
            this.panelBtnMenu.Controls.Add(this.btnUCProdukty);
            this.panelBtnMenu.Controls.Add(this.btnUCKonfiguracja);
            this.panelBtnMenu.Controls.Add(this.btnUCSMTP);
            this.panelBtnMenu.Controls.Add(this.btnUCOdbiorcy);
            this.panelBtnMenu.Location = new System.Drawing.Point(5, 79);
            this.panelBtnMenu.Name = "panelBtnMenu";
            this.panelBtnMenu.Size = new System.Drawing.Size(1102, 519);
            this.panelBtnMenu.TabIndex = 30;
            // 
            // btnUCUtworz
            // 
            this.btnUCUtworz.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCUtworz.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCUtworz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCUtworz.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCUtworz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCUtworz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCUtworz.ForeColor = System.Drawing.Color.Black;
            this.btnUCUtworz.Image = ((System.Drawing.Image)(resources.GetObject("btnUCUtworz.Image")));
            this.btnUCUtworz.Location = new System.Drawing.Point(483, 230);
            this.btnUCUtworz.Name = "btnUCUtworz";
            this.btnUCUtworz.Size = new System.Drawing.Size(120, 180);
            this.btnUCUtworz.TabIndex = 28;
            this.btnUCUtworz.Text = "Utwórz Fakturę";
            this.btnUCUtworz.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCUtworz.UseVisualStyleBackColor = false;
            this.btnUCUtworz.Click += new System.EventHandler(this.btnUCUtworz_Click);
            // 
            // btnUCNadawca
            // 
            this.btnUCNadawca.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCNadawca.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCNadawca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCNadawca.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCNadawca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCNadawca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCNadawca.ForeColor = System.Drawing.Color.Black;
            this.btnUCNadawca.Image = ((System.Drawing.Image)(resources.GetObject("btnUCNadawca.Image")));
            this.btnUCNadawca.Location = new System.Drawing.Point(483, 104);
            this.btnUCNadawca.Name = "btnUCNadawca";
            this.btnUCNadawca.Size = new System.Drawing.Size(246, 120);
            this.btnUCNadawca.TabIndex = 27;
            this.btnUCNadawca.Text = "Nadawca";
            this.btnUCNadawca.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCNadawca.UseVisualStyleBackColor = false;
            this.btnUCNadawca.Click += new System.EventHandler(this.btnUCNadawca_Click);
            // 
            // btnUCProdukty
            // 
            this.btnUCProdukty.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCProdukty.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCProdukty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCProdukty.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCProdukty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCProdukty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCProdukty.ForeColor = System.Drawing.Color.Black;
            this.btnUCProdukty.Image = ((System.Drawing.Image)(resources.GetObject("btnUCProdukty.Image")));
            this.btnUCProdukty.Location = new System.Drawing.Point(231, 104);
            this.btnUCProdukty.Name = "btnUCProdukty";
            this.btnUCProdukty.Size = new System.Drawing.Size(120, 180);
            this.btnUCProdukty.TabIndex = 26;
            this.btnUCProdukty.Text = "Produkty";
            this.btnUCProdukty.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCProdukty.UseVisualStyleBackColor = false;
            this.btnUCProdukty.Click += new System.EventHandler(this.btnUCProdukty_Click);
            // 
            // btnUCKonfiguracja
            // 
            this.btnUCKonfiguracja.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCKonfiguracja.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCKonfiguracja.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCKonfiguracja.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCKonfiguracja.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCKonfiguracja.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCKonfiguracja.ForeColor = System.Drawing.Color.Black;
            this.btnUCKonfiguracja.Image = ((System.Drawing.Image)(resources.GetObject("btnUCKonfiguracja.Image")));
            this.btnUCKonfiguracja.Location = new System.Drawing.Point(609, 230);
            this.btnUCKonfiguracja.Name = "btnUCKonfiguracja";
            this.btnUCKonfiguracja.Size = new System.Drawing.Size(120, 180);
            this.btnUCKonfiguracja.TabIndex = 25;
            this.btnUCKonfiguracja.Text = "Konfiguracja";
            this.btnUCKonfiguracja.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCKonfiguracja.UseVisualStyleBackColor = false;
            this.btnUCKonfiguracja.Click += new System.EventHandler(this.btnUCKonfiguracja_Click);
            // 
            // btnUCSMTP
            // 
            this.btnUCSMTP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCSMTP.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCSMTP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCSMTP.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCSMTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCSMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCSMTP.ForeColor = System.Drawing.Color.Black;
            this.btnUCSMTP.Image = ((System.Drawing.Image)(resources.GetObject("btnUCSMTP.Image")));
            this.btnUCSMTP.Location = new System.Drawing.Point(357, 104);
            this.btnUCSMTP.Name = "btnUCSMTP";
            this.btnUCSMTP.Size = new System.Drawing.Size(120, 180);
            this.btnUCSMTP.TabIndex = 17;
            this.btnUCSMTP.Text = "Email/SMTP";
            this.btnUCSMTP.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCSMTP.UseVisualStyleBackColor = false;
            this.btnUCSMTP.Click += new System.EventHandler(this.btnUCSMTP_Click);
            // 
            // btnUCOdbiorcy
            // 
            this.btnUCOdbiorcy.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUCOdbiorcy.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnUCOdbiorcy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUCOdbiorcy.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnUCOdbiorcy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUCOdbiorcy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnUCOdbiorcy.ForeColor = System.Drawing.Color.Black;
            this.btnUCOdbiorcy.Image = ((System.Drawing.Image)(resources.GetObject("btnUCOdbiorcy.Image")));
            this.btnUCOdbiorcy.Location = new System.Drawing.Point(231, 290);
            this.btnUCOdbiorcy.Name = "btnUCOdbiorcy";
            this.btnUCOdbiorcy.Size = new System.Drawing.Size(246, 120);
            this.btnUCOdbiorcy.TabIndex = 15;
            this.btnUCOdbiorcy.Text = "Odbiorcy";
            this.btnUCOdbiorcy.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUCOdbiorcy.UseVisualStyleBackColor = false;
            this.btnUCOdbiorcy.Click += new System.EventHandler(this.btnUCOdbiorcy_Click);
            // 
            // panelUC
            // 
            this.panelUC.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelUC.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelUC.Location = new System.Drawing.Point(5, 79);
            this.panelUC.Name = "panelUC";
            this.panelUC.Size = new System.Drawing.Size(1102, 519);
            this.panelUC.TabIndex = 31;
            // 
            // btnAPI
            // 
            this.btnAPI.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAPI.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAPI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAPI.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAPI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAPI.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAPI.ForeColor = System.Drawing.Color.Black;
            this.btnAPI.Image = ((System.Drawing.Image)(resources.GetObject("btnAPI.Image")));
            this.btnAPI.Location = new System.Drawing.Point(735, 104);
            this.btnAPI.Name = "btnAPI";
            this.btnAPI.Size = new System.Drawing.Size(120, 306);
            this.btnAPI.TabIndex = 29;
            this.btnAPI.Text = "API";
            this.btnAPI.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAPI.UseVisualStyleBackColor = false;
            this.btnAPI.Click += new System.EventHandler(this.btnAPI_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1112, 629);
            this.Controls.Add(this.panelBtnMenu);
            this.Controls.Add(this.panelStatus);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelUC);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Faktury JK";
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            this.panelBtnMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button btnMinimalizuj;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Label lblNameUC;
        private System.Windows.Forms.Panel panelStatus;
        private System.Windows.Forms.Panel panelBtnMenu;
        private System.Windows.Forms.Button btnUCKonfiguracja;
        private System.Windows.Forms.Button btnUCSMTP;
        private System.Windows.Forms.Button btnUCOdbiorcy;
        private System.Windows.Forms.Panel panelUC;
        private System.Windows.Forms.Button btnUCProdukty;
        private System.Windows.Forms.Button btnUCNadawca;
        private System.Windows.Forms.Button btnUCUtworz;
        private System.Windows.Forms.Button btnAPI;
    }
}

