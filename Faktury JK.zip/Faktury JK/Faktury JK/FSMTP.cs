﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FSMTP : Form
    {
        public FSMTP(string email,Bitmap bmp,string nrfaktury)
        {
            InitializeComponent();
            txtDo.Text = email;
            bmp.Save( nrfaktury+".jpg", ImageFormat.Jpeg);
            listBox1.Items.Add(nrfaktury+".jpg");        
        }
        private void FSMTP_Load(object sender, EventArgs e)
        {
            txtUsername.Text = Faktury_JK.Properties.Settings.Default.cUsernameEmail;
            txtPassword.Text = Faktury_JK.Properties.Settings.Default.cPasswordEmail;
            txtSMTP.Text = Faktury_JK.Properties.Settings.Default.cSMTPEmail;
        }
        private void btnWyslij_Click(object sender, EventArgs e)
        {
            
            try
            {
                SmtpClient smtpClient = new SmtpClient();
                NetworkCredential basicCredential = new NetworkCredential(txtUsername.Text, txtPassword.Text);
                MailMessage message = new MailMessage();
                MailAddress fromAddress = new MailAddress(txtDo.Text);

                smtpClient.Host = txtSMTP.Text;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = basicCredential;
                smtpClient.Timeout = 10000;
                smtpClient.EnableSsl = true;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

                message.From = fromAddress;
                message.Subject = txtSubject.Text;
                message.IsBodyHtml = false;
                message.Body = txtBody.Text;
                message.To.Add(txtDo.Text);

                if (listBox1.Items.Count > 0)
                    foreach (string item in listBox1.Items)
                    {
                        message.Attachments.Add(new Attachment(item));
                    }

                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Wystąpił problez z wysłaniem wiadomości", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.Close();
        }

        private void FSMTP_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                DirectoryInfo d = new DirectoryInfo(System.AppDomain.CurrentDomain.BaseDirectory);
                FileInfo[] Files = d.GetFiles("*.jpg", SearchOption.AllDirectories); //można bez 2 argumentu
                foreach (FileInfo file in Files)
                {
                    if (file.Exists)
                        file.Delete();
                }
            }
            catch
            {
                //
            }

        }

        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
