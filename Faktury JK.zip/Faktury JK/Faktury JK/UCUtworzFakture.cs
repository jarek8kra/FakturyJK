﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;

namespace Faktury_JK
{
    public partial class UCUtworzFakture : UserControl
    {
        public UCUtworzFakture()
        {
            InitializeComponent();
        }
        private static UCUtworzFakture _instance;
        public static UCUtworzFakture Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCUtworzFakture();
                return _instance;
            }
        }
        int numerFaktury;
        private void UCUtworzFakture_Load(object sender, EventArgs e)
        {
            PokazNadawce();
            PokazProdukty();
            PokazNumer();
            labelDataWystawienia.Text = DateTime.Now.ToString("dd-MM-yyyy");

        }
        BindingSource bs;
        void PokazProdukty()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("ProduktyView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView2.DataSource = dt;
            bs = new BindingSource();
            bs.DataSource = dt;
            dataGridView2.Columns["Id"].Visible = false;
            dataGridView2.Columns["Nazwa"].Width = 400;
            dataGridView2.Columns["Vat"].HeaderText = "Vat[%]";
            con.Close();
        }
        void PokazNumer()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("CountFaktury", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            labelCount.DataBindings.Clear();
            labelCount.DataBindings.Add("Text", dt, "ilosc");

            con.Close();
        }
        void PokazNadawce()
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("NadawcaView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            labelSprzedawcaNazwa.DataBindings.Add("Text", dt, "Nazwa");
            labelSprzedawcaAdres1.DataBindings.Add("Text", dt, "AdresUlicaNumer");
            labelSprzedawcaAdres2.DataBindings.Add("Text", dt, "AdresKodMiasto");
            labelSprzedawcaNIP.DataBindings.Add("Text", dt, "NIP");
            labelSprzedawcaREGON.DataBindings.Add("Text", dt, "REGON");
            labelNrKonta.DataBindings.Add("Text", dt, "NrKonta");
            con.Close();
        }

        public Bitmap CreateBMP()
        {
            int width = Convert.ToInt32(panelFaktura.Width);
            int height = Convert.ToInt32(panelFaktura.Height);
            Bitmap bmp = new Bitmap(width, height);
            panelFaktura.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
            return bmp;
        }
        void PokazPodglad()
        {
            Bitmap bmp = CreateBMP();
            FUtworzFakturePreview fufp = new FUtworzFakturePreview(bmp);
            DialogResult result = fufp.ShowDialog();
        }

        void InsertFaktury()
        {
            Bitmap bmp = CreateBMP();
            //int width = Convert.ToInt32(panelFaktura.Width);
            //int height = Convert.ToInt32(panelFaktura.Height);
            //Bitmap bmp = new Bitmap(width, height);
            //panelFaktura.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));

            MemoryStream ms = new MemoryStream();
            //PictureBox pb = new PictureBox();
            //pb.Image = bmp;
            //pb.Image.Save(ms, ImageFormat.Jpeg);
            bmp.Save(ms, ImageFormat.Jpeg);
            byte[] PhotoByte = ms.ToArray();

            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("AddFaktury", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@nrfaktury", SqlDbType.Int).Value = numerFaktury;
            cmd.Parameters.AddWithValue("@datawystawienia", SqlDbType.NVarChar).Value = DateTime.Now.ToString("dd-MM-yyyy");
            cmd.Parameters.AddWithValue("@idodbiorcy", SqlDbType.Int).Value = Int32.Parse(lblFOdbiorcyID.Text);
            cmd.Parameters.AddWithValue("@obraz", SqlDbType.VarBinary).Value = PhotoByte;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void dataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells[0].Value = (e.RowIndex + 1).ToString();
            dataGridView1.Rows[e.RowIndex].Cells[2].Value = "szt.";
            //var rowHeaderText = (e.RowIndex + 1).ToString();
            //var dgv = sender as DataGridView;
        }

        void PozwolUtworzyc()
        {
            if(dataGridView3.Rows.Count>0&&
                lblNabywcaNazwa.Text!=string.Empty
                )
            {
                btnZapisz.Enabled = true;
            }
            else
            {
                btnZapisz.Enabled = false;
            }
        }
        void CleardlaNowej()
        {
            dataGridView1.Rows.Clear();
            dataGridView3.Rows.Clear();
            dataGridView4.Rows.Clear();
            PokazNumer();
        }
        private void btnNabywca_Click(object sender, EventArgs e)
        {
            
            FUtworzFaktureNabywcaSelect fufns = new FUtworzFaktureNabywcaSelect();
            DialogResult result = fufns.ShowDialog();
            lblNabywcaNazwa.Text = fufns.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            lblNabywcaAdres1.Text = fufns.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            lblNabywcaAdres2.Text = fufns.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            lblNnabywcaNIP.Text = "NIP: " + fufns.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            lblNabywcaRegon.Text = "REGON: " + fufns.dataGridView1.CurrentRow.Cells[6].Value.ToString();
            lblFOdbiorcyID.Text = fufns.labelIDOdbiorcyView.Text;

            lblFNabywcaNazwa.Text = lblNabywcaNazwa.Text;
            lblFNabywcaAdres1.Text = lblNabywcaAdres1.Text;
            lblFNabywcaAdres2.Text = lblNabywcaAdres2.Text;
            lblFNabywcaNIP.Text =  lblNnabywcaNIP.Text;
            lblFNabywcaRegon.Text =  lblNabywcaRegon.Text;

            PozwolUtworzyc();

        }

        private void btnDodajProdukt_Click(object sender, EventArgs e)
        {
            string nazwa = dataGridView2.CurrentRow.Cells["Nazwa"].Value.ToString();
            double cena = double.Parse(dataGridView2.CurrentRow.Cells["Cena"].Value.ToString());
            int vat = Int32.Parse(dataGridView2.CurrentRow.Cells["Vat"].Value.ToString());
            int ilosc = Int32.Parse(textBoxIlosc.Text);
            cena = cena * ilosc;
            dataGridView3.Rows.Add(nazwa,cena,vat,ilosc);
            textBoxIlosc.Clear();
            btnDodajProdukt.Enabled = false;

            PozwolUtworzyc();


        }


        private void txtNazwaFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Nazwa";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNazwaFilter.Text);
        }

        private void dataGridView2_CellEnter(object sender, DataGridViewCellEventArgs e)
        {       
            lblNazwa.Text = dataGridView2.CurrentRow.Cells["Nazwa"].Value.ToString();
        }

        private void textBoxIlosc_TextChanged(object sender, EventArgs e)
        {
            if (lblNazwa.Text != string.Empty && textBoxIlosc.Text != string.Empty)
                btnDodajProdukt.Enabled = true;
            else
                btnDodajProdukt.Enabled = false;
        }

        private void textBoxIlosc_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);//tylko cyfry
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 4)
            {
                dataGridView3.Rows.Remove(dataGridView3.Rows[e.RowIndex]);
            }
            PozwolUtworzyc();
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            PokazNumer();
            numerFaktury = Int32.Parse(labelCount.Text) + 1;
            lblNumerFaktury.Text = "FV Nr.: " + numerFaktury.ToString();

            btnZapisz.Enabled = false;
            foreach (DataGridViewRow row in dataGridView3.Rows)
            {
                string nazwa = row.Cells["NazwaX"].Value.ToString();
                int ilosc = Int32.Parse(row.Cells["IloscX"].Value.ToString());
                double cenaNetto = double.Parse(row.Cells["CenaX"].Value.ToString());
                int vat = Int32.Parse(row.Cells["VatX"].Value.ToString());
                double wartoscNetto = Math.Truncate(cenaNetto * 100) / 100;
                double wartoscVat = (cenaNetto * vat) / 100;
                double wartoscBrutto = wartoscNetto + wartoscVat;
                dataGridView1.Rows.Add(null, nazwa, null, ilosc, cenaNetto, vat, (decimal)wartoscNetto, (decimal)wartoscVat, (decimal)wartoscBrutto);
            }

            dataGridView1.ClearSelection();
            dataGridView1.Height = 31 + 22 * dataGridView1.Rows.Count;
            dataGridView4.Top = dataGridView1.Top + dataGridView1.Height + 30;
            HashSet<int> hs = new HashSet<int>();
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                  hs.Add(Int32.Parse(row.Cells["Vat"].Value.ToString()));
            }
            List<int> ls = new List<int>();
            ls = hs.ToList();


            foreach (var item in ls)
            {
                double warnet = 0;
                double warvat = 0;
                double warbru = 0;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (Int32.Parse(row.Cells["Vat"].Value.ToString()) == item)
                    {
                        warnet += double.Parse(row.Cells["WartoscNetto"].Value.ToString());
                        warvat += double.Parse(row.Cells["WartoscVAT"].Value.ToString());
                        warbru += double.Parse(row.Cells["WartoscBrutto"].Value.ToString());
                    }
                }
                dataGridView4.Rows.Add(null, item, warnet, warvat, warbru);
            }
                double warnets = 0;
                double warvats = 0;
                double warbrus = 0;

            foreach (DataGridViewRow row in dataGridView4.Rows)
            {
                warnets += double.Parse(row.Cells["WartoscNettoa"].Value.ToString());
                warvats += double.Parse(row.Cells["WartoscVATa"].Value.ToString());
                warbrus += double.Parse(row.Cells["WartoscBruttoa"].Value.ToString());
            }
            dataGridView4.Rows.Add("Razem", null, warnets, warvats, warbrus);

            labelRazem.Text = $"{warbrus:C2}";
            labelDozaplaty.Text = labelRazem.Text;
            if (radioButton1.Checked == true)
            {
                labelForma.Text = "przelew";
            }   
            else
            {
            labelForma.Text = "gotówka";
            labelNrKonta.Visible = false;
            label8.Visible = false;
            }

            labelTermin.Text = dateTimePicker1.Value.ToString("dd-MM-yyyy");           
            dataGridView4.Height = 31 + 22 * dataGridView4.Rows.Count;
            panelpodsumowanie.Top = dataGridView4.Top + dataGridView4.Height + 20;

            dataGridView4.ClearSelection();
            

            //Numerowanie


            PokazPodglad();
            InsertFaktury();
            CleardlaNowej();
            }


    }
}
