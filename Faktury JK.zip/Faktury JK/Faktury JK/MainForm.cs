﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            panelBtnMenu.BringToFront();
        }
        private void btnMinimalizuj_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void btnZamknij_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnUCOdbiorcy_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCOdbiorcy.Instance))
            {
                panelUC.Controls.Add(UCOdbiorcy.Instance);
                UCOdbiorcy.Instance.Dock = DockStyle.Fill;
                UCOdbiorcy.Instance.BringToFront();
            }
            else
                UCOdbiorcy.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }

        private void btnUCProdukty_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCProdukty.Instance))
            {
                panelUC.Controls.Add(UCProdukty.Instance);
                UCProdukty.Instance.Dock = DockStyle.Fill;
                UCProdukty.Instance.BringToFront();
            }
            else
                UCProdukty.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }



        private void btnUCNadawca_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCNadawca.Instance))
            {
                panelUC.Controls.Add(UCNadawca.Instance);
                UCNadawca.Instance.Dock = DockStyle.Fill;
                UCNadawca.Instance.BringToFront();
                UCNadawca.Instance.BringToFront();
                UCNadawca.Instance.BringToFront();
            }
            else
                UCNadawca.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }

        private void btnUCUtworz_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCUtworzFakture.Instance))
            {
                panelUC.Controls.Add(UCUtworzFakture.Instance);
                UCUtworzFakture.Instance.Dock = DockStyle.Fill;
                UCUtworzFakture.Instance.BringToFront();
            }
            else
                UCUtworzFakture.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }



        private void btnUCSMTP_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCSMTP.Instance))
            {
                panelUC.Controls.Add(UCSMTP.Instance);
                UCSMTP.Instance.Dock = DockStyle.Fill;
                UCSMTP.Instance.BringToFront();
                UCSMTP.Instance.BringToFront();
                UCSMTP.Instance.BringToFront();
            }
            else
                UCSMTP.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }

        private void btnUCKonfiguracja_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCKonfiguracja.Instance))
            {
                panelUC.Controls.Add(UCKonfiguracja.Instance);
                UCKonfiguracja.Instance.Dock = DockStyle.Fill;
                UCKonfiguracja.Instance.BringToFront();
            }
            else
                UCKonfiguracja.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }

        private void btnAPI_Click(object sender, EventArgs e)
        {
            if (!panelUC.Controls.Contains(UCAPI.Instance))
            {
                panelUC.Controls.Add(UCAPI.Instance);
                UCAPI.Instance.Dock = DockStyle.Fill;
                UCAPI.Instance.BringToFront();
            }
            else
                UCAPI.Instance.BringToFront();
            panelBtnMenu.SendToBack();
        }
    }
}
