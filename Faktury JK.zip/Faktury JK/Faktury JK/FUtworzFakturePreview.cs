﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FUtworzFakturePreview : Form
    {
        public FUtworzFakturePreview(Bitmap bmp)
        {
            InitializeComponent();
            pictureBox1.Image = bmp;
        }


        private void btnDrukuj_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void btnPodgladWydruku_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Show();
        }

        private void btnZapiszJPG_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Obrazy (*.jpg)|*.jpg";
            if (dialog.ShowDialog() == DialogResult.OK) 
            {
                int width = Convert.ToInt32(pb.Width);
                int height = Convert.ToInt32(pb.Height);
                Bitmap bmp = new Bitmap(width, height);
                pb.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, width, height));
                bmp.Save(dialog.FileName, ImageFormat.Jpeg);
            }
        }
        
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            
            Bitmap bm = new Bitmap(this.pb.Width, this.pb.Height);
            pb.DrawToBitmap(bm, new System.Drawing.Rectangle(0, 0, this.pb.Width, this.pb.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }

        PictureBox pb;
        private void FUtworzFakturePreview_Load(object sender, EventArgs e)
        {
            pb = new PictureBox();
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
            pb.Image = pictureBox1.Image;
            pb.Width = 779;
            pb.Height = 883;         
        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            pictureBox1.Width = (Int32.Parse(pictureBox1.Height.ToString()) * 8) / 10;
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
