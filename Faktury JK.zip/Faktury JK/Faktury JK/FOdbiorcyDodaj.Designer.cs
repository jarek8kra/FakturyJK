﻿namespace Faktury_JK
{
    partial class FOdbiorcyDodaj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label nazwaLabel;
            System.Windows.Forms.Label UlicaNumerLabel;
            System.Windows.Forms.Label KodMiejscowoscLabel;
            System.Windows.Forms.Label NIPLabel;
            System.Windows.Forms.Label REGONlabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FOdbiorcyDodaj));
            System.Windows.Forms.Label label1;
            this.NazwaTextBox = new System.Windows.Forms.TextBox();
            this.UlNumerTextBox = new System.Windows.Forms.TextBox();
            this.KodMiejscowoscTextBox = new System.Windows.Forms.TextBox();
            this.btnZapisz = new System.Windows.Forms.Button();
            this.btnAnuluj = new System.Windows.Forms.Button();
            this.NIPtextBox = new System.Windows.Forms.TextBox();
            this.REGONtextBox = new System.Windows.Forms.TextBox();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            nazwaLabel = new System.Windows.Forms.Label();
            UlicaNumerLabel = new System.Windows.Forms.Label();
            KodMiejscowoscLabel = new System.Windows.Forms.Label();
            NIPLabel = new System.Windows.Forms.Label();
            REGONlabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nazwaLabel
            // 
            nazwaLabel.AutoSize = true;
            nazwaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            nazwaLabel.Location = new System.Drawing.Point(76, 34);
            nazwaLabel.Name = "nazwaLabel";
            nazwaLabel.Size = new System.Drawing.Size(110, 16);
            nazwaLabel.TabIndex = 53;
            nazwaLabel.Text = "Nazwa Odbiorcy:";
            // 
            // UlicaNumerLabel
            // 
            UlicaNumerLabel.AutoSize = true;
            UlicaNumerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            UlicaNumerLabel.Location = new System.Drawing.Point(127, 62);
            UlicaNumerLabel.Name = "UlicaNumerLabel";
            UlicaNumerLabel.Size = new System.Drawing.Size(59, 16);
            UlicaNumerLabel.TabIndex = 54;
            UlicaNumerLabel.Text = "Ulica, nr:";
            // 
            // KodMiejscowoscLabel
            // 
            KodMiejscowoscLabel.AutoSize = true;
            KodMiejscowoscLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            KodMiejscowoscLabel.Location = new System.Drawing.Point(67, 90);
            KodMiejscowoscLabel.Name = "KodMiejscowoscLabel";
            KodMiejscowoscLabel.Size = new System.Drawing.Size(119, 16);
            KodMiejscowoscLabel.TabIndex = 55;
            KodMiejscowoscLabel.Text = "Kod, Miejscowość:";
            // 
            // NIPLabel
            // 
            NIPLabel.AutoSize = true;
            NIPLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            NIPLabel.Location = new System.Drawing.Point(153, 121);
            NIPLabel.Name = "NIPLabel";
            NIPLabel.Size = new System.Drawing.Size(33, 16);
            NIPLabel.TabIndex = 56;
            NIPLabel.Text = "NIP:";
            // 
            // REGONlabel
            // 
            REGONlabel.AutoSize = true;
            REGONlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            REGONlabel.Location = new System.Drawing.Point(126, 149);
            REGONlabel.Name = "REGONlabel";
            REGONlabel.Size = new System.Drawing.Size(60, 16);
            REGONlabel.TabIndex = 58;
            REGONlabel.Text = "REGON:";
            // 
            // NazwaTextBox
            // 
            this.NazwaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NazwaTextBox.Location = new System.Drawing.Point(192, 31);
            this.NazwaTextBox.MaxLength = 50;
            this.NazwaTextBox.Name = "NazwaTextBox";
            this.NazwaTextBox.Size = new System.Drawing.Size(189, 22);
            this.NazwaTextBox.TabIndex = 0;
            this.NazwaTextBox.TextChanged += new System.EventHandler(this.NazwaTextBox_TextChanged);
            // 
            // UlNumerTextBox
            // 
            this.UlNumerTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.UlNumerTextBox.Location = new System.Drawing.Point(192, 59);
            this.UlNumerTextBox.MaxLength = 50;
            this.UlNumerTextBox.Name = "UlNumerTextBox";
            this.UlNumerTextBox.Size = new System.Drawing.Size(189, 22);
            this.UlNumerTextBox.TabIndex = 1;
            this.UlNumerTextBox.TextChanged += new System.EventHandler(this.UlNumerTextBox_TextChanged);
            // 
            // KodMiejscowoscTextBox
            // 
            this.KodMiejscowoscTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.KodMiejscowoscTextBox.Location = new System.Drawing.Point(192, 87);
            this.KodMiejscowoscTextBox.MaxLength = 50;
            this.KodMiejscowoscTextBox.Name = "KodMiejscowoscTextBox";
            this.KodMiejscowoscTextBox.Size = new System.Drawing.Size(189, 22);
            this.KodMiejscowoscTextBox.TabIndex = 2;
            this.KodMiejscowoscTextBox.TextChanged += new System.EventHandler(this.KodMiejscowoscTextBox_TextChanged);
            // 
            // btnZapisz
            // 
            this.btnZapisz.BackColor = System.Drawing.Color.Transparent;
            this.btnZapisz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapisz.Enabled = false;
            this.btnZapisz.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZapisz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZapisz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZapisz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapisz.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZapisz.Image = ((System.Drawing.Image)(resources.GetObject("btnZapisz.Image")));
            this.btnZapisz.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZapisz.Location = new System.Drawing.Point(73, 221);
            this.btnZapisz.Name = "btnZapisz";
            this.btnZapisz.Size = new System.Drawing.Size(150, 60);
            this.btnZapisz.TabIndex = 6;
            this.btnZapisz.Text = "Zapisz   ";
            this.btnZapisz.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZapisz.UseVisualStyleBackColor = false;
            this.btnZapisz.Click += new System.EventHandler(this.btnZapisz_Click);
            // 
            // btnAnuluj
            // 
            this.btnAnuluj.BackColor = System.Drawing.Color.Transparent;
            this.btnAnuluj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAnuluj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAnuluj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnAnuluj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnAnuluj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnuluj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAnuluj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAnuluj.Image = ((System.Drawing.Image)(resources.GetObject("btnAnuluj.Image")));
            this.btnAnuluj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnuluj.Location = new System.Drawing.Point(231, 221);
            this.btnAnuluj.Name = "btnAnuluj";
            this.btnAnuluj.Size = new System.Drawing.Size(150, 60);
            this.btnAnuluj.TabIndex = 7;
            this.btnAnuluj.Text = "Anuluj    ";
            this.btnAnuluj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAnuluj.UseVisualStyleBackColor = false;
            this.btnAnuluj.Click += new System.EventHandler(this.btnAnuluj_Click);
            // 
            // NIPtextBox
            // 
            this.NIPtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NIPtextBox.Location = new System.Drawing.Point(192, 118);
            this.NIPtextBox.MaxLength = 50;
            this.NIPtextBox.Name = "NIPtextBox";
            this.NIPtextBox.Size = new System.Drawing.Size(131, 22);
            this.NIPtextBox.TabIndex = 3;
            this.NIPtextBox.TextChanged += new System.EventHandler(this.NIPtextBox_TextChanged);
            // 
            // REGONtextBox
            // 
            this.REGONtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.REGONtextBox.Location = new System.Drawing.Point(192, 146);
            this.REGONtextBox.MaxLength = 50;
            this.REGONtextBox.Name = "REGONtextBox";
            this.REGONtextBox.Size = new System.Drawing.Size(131, 22);
            this.REGONtextBox.TabIndex = 4;
            this.REGONtextBox.TextChanged += new System.EventHandler(this.REGONtextBox_TextChanged);
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EmailtextBox.Location = new System.Drawing.Point(192, 174);
            this.EmailtextBox.MaxLength = 50;
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(189, 22);
            this.EmailtextBox.TabIndex = 5;
            this.EmailtextBox.TextChanged += new System.EventHandler(this.EmailtextBox_TextChanged);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label1.Location = new System.Drawing.Point(141, 177);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(45, 16);
            label1.TabIndex = 60;
            label1.Text = "Email:";
            // 
            // FOdbiorcyDodaj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(464, 311);
            this.Controls.Add(this.EmailtextBox);
            this.Controls.Add(label1);
            this.Controls.Add(this.NIPtextBox);
            this.Controls.Add(this.REGONtextBox);
            this.Controls.Add(REGONlabel);
            this.Controls.Add(nazwaLabel);
            this.Controls.Add(this.NazwaTextBox);
            this.Controls.Add(UlicaNumerLabel);
            this.Controls.Add(this.UlNumerTextBox);
            this.Controls.Add(KodMiejscowoscLabel);
            this.Controls.Add(this.KodMiejscowoscTextBox);
            this.Controls.Add(NIPLabel);
            this.Controls.Add(this.btnZapisz);
            this.Controls.Add(this.btnAnuluj);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FOdbiorcyDodaj";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Odbiorcy/Dodaj";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NazwaTextBox;
        private System.Windows.Forms.TextBox UlNumerTextBox;
        private System.Windows.Forms.TextBox KodMiejscowoscTextBox;
        private System.Windows.Forms.Button btnZapisz;
        private System.Windows.Forms.Button btnAnuluj;
        private System.Windows.Forms.TextBox NIPtextBox;
        private System.Windows.Forms.TextBox REGONtextBox;
        private System.Windows.Forms.TextBox EmailtextBox;
    }
}