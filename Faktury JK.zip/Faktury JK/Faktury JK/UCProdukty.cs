﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Faktury_JK
{
    public partial class UCProdukty : UserControl
    {
        public UCProdukty()
        {
            InitializeComponent();
        }
        private static UCProdukty _instance;
        public static UCProdukty Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCProdukty();
                return _instance;
            }
        }

        private void UCProdukty_Load(object sender, EventArgs e)
        {
            Odswiezanie();
            ZliczanieRekordow();
        }
        BindingSource bs;
        void Odswiezanie()
        {

            //produktyViewTableAdapter.Fill(dbFakturyJKDataSet.ProduktyView);
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("ProduktyView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            dataGridView1.DataSource = dt;
            bs =  new BindingSource();
            bs.DataSource = dt;
            dataGridView1.Columns["Id"].Visible = false;
            dataGridView1.Columns["Nazwa"].Width = 400;
            dataGridView1.Columns["Vat"].HeaderText = "Vat[%]";
            labelIDProduktyView.DataBindings.Clear();
            labelIDProduktyView.DataBindings.Add("Text", dt, "Id");
            con.Close();
        }
        public void ZliczanieRekordow()
        {
            lblCount.Text = dataGridView1.Rows.Count.ToString();
            int ile = dataGridView1.Rows.Count;
            if (ile > 0)
            {
                btnEdytuj.Enabled = true;
                btnUsun.Enabled = true;
            }
            else
            {
                btnEdytuj.Enabled = false;
                btnUsun.Enabled = false;
            }
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            FProduktyDodaj fpd = new FProduktyDodaj();
            DialogResult result = fpd.ShowDialog();
            Odswiezanie();
            ZliczanieRekordow();
        }

        private void txtNazwaFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Nazwa";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNazwaFilter.Text);
            ZliczanieRekordow();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnEdytuj_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(labelIDProduktyView.Text);
            FProduktyEdytuj fpe = new FProduktyEdytuj(id);
            DialogResult result = fpe.ShowDialog();
            Odswiezanie();
        }

        private void btnUsun_Click(object sender, EventArgs e)
        {
            string Nazwa = dataGridView1.CurrentRow.Cells[1].Value.ToString();

            if (MessageBox.Show("Usunąć produkt: " + Nazwa + "?", "Faktury JK", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
                SqlCommand cmd = new SqlCommand("DeleteProduktyById", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = Int32.Parse(labelIDProduktyView.Text);
                cmd.ExecuteNonQuery();
                con.Close();

                Odswiezanie();
                ZliczanieRekordow();
            }
        }

        private void btnOdswiez_Click(object sender, EventArgs e)
        {
            Odswiezanie();
            ZliczanieRekordow();
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex];
                dataGridView1.Rows[e.RowIndex].Selected = true;
                dataGridView1.Focus();
            }
        }

        private void toolStripMenuDodaj_Click(object sender, EventArgs e)
        {
            btnDodaj_Click(null, null);
        }

        private void toolStripMenuEdytuj_Click(object sender, EventArgs e)
        {
            btnEdytuj_Click(null, null);
        }

        private void toolStripMenuUsun_Click(object sender, EventArgs e)
        {
            btnUsun_Click(null, null);
        }

        private void toolStripMenuOdswiez_Click(object sender, EventArgs e)
        {
            btnOdswiez_Click(null, null);
        }
    }
}
