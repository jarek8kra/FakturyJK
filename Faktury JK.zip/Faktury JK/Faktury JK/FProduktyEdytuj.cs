﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FProduktyEdytuj : Form
    {
        public FProduktyEdytuj(int id)
        {
            InitializeComponent();
            labelIDProdukty.Text = id.ToString();
        }

        private void FProduktyEdytuj_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("GetProduktyById", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = Int32.Parse(labelIDProdukty.Text);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            NazwaProduktuTextBox.DataBindings.Add("Text", dt, "Nazwa");
            CenaTextBox.DataBindings.Add("Text", dt, "Cena");
            VattextBox.DataBindings.Add("Text", dt, "Vat");
            con.Close();
        }

        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("UpdateProdukty", con);

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = Int32.Parse(labelIDProdukty.Text);
            cmd.Parameters.AddWithValue("@nazwa", SqlDbType.VarChar).Value = NazwaProduktuTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@cena", SqlDbType.VarChar).Value = double.Parse(CenaTextBox.Text.Trim());
            cmd.Parameters.AddWithValue("@vat", SqlDbType.Int).Value = Int32.Parse(VattextBox.Text.Trim());
            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }
        void Sprawdzanie()
        {
            if(NazwaProduktuTextBox.Text!=string.Empty&&
                CenaTextBox.Text!=string.Empty&&
                VattextBox.Text!=string.Empty)
            {
                btnZapisz.Enabled = true;
            }
            else
            {
                btnZapisz.Enabled = false;
            }
        }

        private void NazwaProduktuTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void CenaTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void VattextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }
    }
}
