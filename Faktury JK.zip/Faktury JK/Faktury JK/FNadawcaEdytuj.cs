﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FNadawcaEdytuj : Form
    {
        public FNadawcaEdytuj()
        {
            InitializeComponent();
        }
        void Sprawdzanie()
        {
            if (NazwaTextBox.Text != string.Empty &&
                UlNumerTextBox.Text != string.Empty &&
                KodMiejscowoscTextBox.Text != string.Empty &&
                NIPtextBox.Text != string.Empty &&
                REGONtextBox.Text != string.Empty)
            {
                btnZapisz.Enabled = true;
            }
            else
            {
                btnZapisz.Enabled = false;
            }
        }
        private void FNadawcaEdytuj_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("NadawcaView", con);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            NazwaTextBox.DataBindings.Add("Text", dt, "Nazwa");
            UlNumerTextBox.DataBindings.Add("Text", dt, "AdresUlicaNumer");
            KodMiejscowoscTextBox.DataBindings.Add("Text", dt, "AdresKodMiasto");
            NIPtextBox.DataBindings.Add("Text", dt, "NIP");
            REGONtextBox.DataBindings.Add("Text", dt, "REGON");
            NrKontatextBox.DataBindings.Add("Text", dt, "NrKonta");
            con.Close();
        }

        private void NazwaTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void REGONtextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void NIPtextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void UlNumerTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void KodMiejscowoscTextBox_TextChanged(object sender, EventArgs e)
        {
            Sprawdzanie();
        }

        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
            SqlCommand cmd = new SqlCommand("UpdateNadawca", con);

            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@id", SqlDbType.Int).Value = 1;
            cmd.Parameters.AddWithValue("@nazwa", SqlDbType.VarChar).Value = NazwaTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@adresun", SqlDbType.VarChar).Value = UlNumerTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@adreskm", SqlDbType.VarChar).Value = KodMiejscowoscTextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@nip", SqlDbType.VarChar).Value = NIPtextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@regon", SqlDbType.VarChar).Value = REGONtextBox.Text.Trim();
            cmd.Parameters.AddWithValue("@nrkonta", SqlDbType.VarChar).Value = NrKontatextBox.Text.Trim();

            cmd.ExecuteNonQuery();
            con.Close();
            this.Close();
        }

        private void NrKontatextBox_TextChanged(object sender, EventArgs e)
        {
            labelCount.Text = NrKontatextBox.Text.Length.ToString();
        }
    }
}
