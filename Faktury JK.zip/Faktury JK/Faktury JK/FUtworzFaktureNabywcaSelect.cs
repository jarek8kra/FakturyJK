﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class FUtworzFaktureNabywcaSelect : Form
    {
        public FUtworzFaktureNabywcaSelect()
        {
            InitializeComponent();
        }
 BindingSource bs;
        private void FUtworzFaktureNabywcaSelect_Load(object sender, EventArgs e)
        {
           

                //odbiorcyViewTableAdapter.Fill(dbFakturyJKDataSet.OdbiorcyView);

                SqlConnection con = new SqlConnection(Faktury_JK.Properties.Settings.Default.dbFakturyJKConnectionString);
                SqlCommand cmd = new SqlCommand("OdbiorcyView", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                dataGridView1.DataSource = dt;
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.Columns["Id"].Visible = false;
                dataGridView1.Columns["Email"].Visible = false;
                labelIDOdbiorcyView.DataBindings.Clear();
                labelIDOdbiorcyView.DataBindings.Add("Text", dt, "Id");
                con.Close();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                
                this.Close();
            }
        }

        private void txtNazwaFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "Nazwa";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNazwaFilter.Text);
        }

        private void txtAdres1Filter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "AdresUlicaNumer";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtAdres1Filter.Text);
        }

        private void txtAdres2Filter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "AdresKodMiasto";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtAdres2Filter.Text);
        }

        private void txtNIPFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "NIP";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtNIPFilter.Text);
        }

        private void txtREGONFilter_TextChanged(object sender, EventArgs e)
        {
            string filterField = "REGON";
            bs.Filter = string.Format("[{0}] LIKE '{1}%'", filterField, txtREGONFilter.Text);
        }

        private void txtNazwaFilter_Enter(object sender, EventArgs e)
        {
            // txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
        }

        private void txtAdres1Filter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
           // txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
        }

        private void txtAdres2Filter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            //txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
        }

        private void txtNIPFilter_Enter(object sender, EventArgs e)
        {
             txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            //txtNIPFilter.Text = string.Empty;
            txtREGONFilter.Text = string.Empty;
        }

        private void txtREGONFilter_Enter(object sender, EventArgs e)
        {
            txtNazwaFilter.Text = string.Empty;
            txtAdres1Filter.Text = string.Empty;
            txtAdres2Filter.Text = string.Empty;
            txtNIPFilter.Text = string.Empty;
            //txtREGONFilter.Text = string.Empty;
        }
    }
}
