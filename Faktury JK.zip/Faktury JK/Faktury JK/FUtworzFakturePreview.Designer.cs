﻿namespace Faktury_JK
{
    partial class FUtworzFakturePreview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FUtworzFakturePreview));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnPodgladWydruku = new System.Windows.Forms.Button();
            this.labelIDProduktyView = new System.Windows.Forms.Label();
            this.labelIDOdbiorcyView = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnZapiszJPG = new System.Windows.Forms.Button();
            this.btnDrukuj = new System.Windows.Forms.Button();
            this.uzytkownicyIDLabel1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnZamknij);
            this.panel1.Controls.Add(this.btnPodgladWydruku);
            this.panel1.Controls.Add(this.labelIDProduktyView);
            this.panel1.Controls.Add(this.labelIDOdbiorcyView);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnZapiszJPG);
            this.panel1.Controls.Add(this.btnDrukuj);
            this.panel1.Controls.Add(this.uzytkownicyIDLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(200, 595);
            this.panel1.TabIndex = 61;
//            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.Transparent;
            this.btnZamknij.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZamknij.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZamknij.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZamknij.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZamknij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZamknij.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZamknij.Image = ((System.Drawing.Image)(resources.GetObject("btnZamknij.Image")));
            this.btnZamknij.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZamknij.Location = new System.Drawing.Point(25, 296);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(150, 60);
            this.btnZamknij.TabIndex = 57;
            this.btnZamknij.Text = "Zamknij  ";
            this.btnZamknij.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnPodgladWydruku
            // 
            this.btnPodgladWydruku.BackColor = System.Drawing.Color.Transparent;
            this.btnPodgladWydruku.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPodgladWydruku.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnPodgladWydruku.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnPodgladWydruku.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnPodgladWydruku.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPodgladWydruku.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPodgladWydruku.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnPodgladWydruku.Image = ((System.Drawing.Image)(resources.GetObject("btnPodgladWydruku.Image")));
            this.btnPodgladWydruku.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPodgladWydruku.Location = new System.Drawing.Point(25, 141);
            this.btnPodgladWydruku.Name = "btnPodgladWydruku";
            this.btnPodgladWydruku.Size = new System.Drawing.Size(150, 60);
            this.btnPodgladWydruku.TabIndex = 56;
            this.btnPodgladWydruku.Text = "Podgląd \r\nwydruku";
            this.btnPodgladWydruku.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPodgladWydruku.UseVisualStyleBackColor = false;
            this.btnPodgladWydruku.Click += new System.EventHandler(this.btnPodgladWydruku_Click);
            // 
            // labelIDProduktyView
            // 
            this.labelIDProduktyView.AutoSize = true;
            this.labelIDProduktyView.Location = new System.Drawing.Point(-15, -15);
            this.labelIDProduktyView.Name = "labelIDProduktyView";
            this.labelIDProduktyView.Size = new System.Drawing.Size(35, 13);
            this.labelIDProduktyView.TabIndex = 55;
            this.labelIDProduktyView.Text = "label1";
            // 
            // labelIDOdbiorcyView
            // 
            this.labelIDOdbiorcyView.AutoSize = true;
            this.labelIDOdbiorcyView.Location = new System.Drawing.Point(-15, -15);
            this.labelIDOdbiorcyView.Name = "labelIDOdbiorcyView";
            this.labelIDOdbiorcyView.Size = new System.Drawing.Size(35, 13);
            this.labelIDOdbiorcyView.TabIndex = 54;
            this.labelIDOdbiorcyView.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(26, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 20);
            this.label3.TabIndex = 50;
            this.label3.Text = "Podgląd Faktury:";
            // 
            // btnZapiszJPG
            // 
            this.btnZapiszJPG.BackColor = System.Drawing.Color.Transparent;
            this.btnZapiszJPG.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnZapiszJPG.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnZapiszJPG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnZapiszJPG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnZapiszJPG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZapiszJPG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnZapiszJPG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnZapiszJPG.Image = ((System.Drawing.Image)(resources.GetObject("btnZapiszJPG.Image")));
            this.btnZapiszJPG.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnZapiszJPG.Location = new System.Drawing.Point(25, 218);
            this.btnZapiszJPG.Name = "btnZapiszJPG";
            this.btnZapiszJPG.Size = new System.Drawing.Size(150, 60);
            this.btnZapiszJPG.TabIndex = 2;
            this.btnZapiszJPG.Text = "Zapisz jako\r\n JPG  ";
            this.btnZapiszJPG.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnZapiszJPG.UseVisualStyleBackColor = false;
            this.btnZapiszJPG.Click += new System.EventHandler(this.btnZapiszJPG_Click);
            // 
            // btnDrukuj
            // 
            this.btnDrukuj.BackColor = System.Drawing.Color.Transparent;
            this.btnDrukuj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDrukuj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnDrukuj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnDrukuj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnDrukuj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrukuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnDrukuj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnDrukuj.Image = ((System.Drawing.Image)(resources.GetObject("btnDrukuj.Image")));
            this.btnDrukuj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDrukuj.Location = new System.Drawing.Point(25, 64);
            this.btnDrukuj.Name = "btnDrukuj";
            this.btnDrukuj.Size = new System.Drawing.Size(150, 60);
            this.btnDrukuj.TabIndex = 1;
            this.btnDrukuj.Text = "Drukuj   ";
            this.btnDrukuj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDrukuj.UseVisualStyleBackColor = false;
            this.btnDrukuj.Click += new System.EventHandler(this.btnDrukuj_Click);
            // 
            // uzytkownicyIDLabel1
            // 
            this.uzytkownicyIDLabel1.Location = new System.Drawing.Point(128, -32);
            this.uzytkownicyIDLabel1.Name = "uzytkownicyIDLabel1";
            this.uzytkownicyIDLabel1.Size = new System.Drawing.Size(47, 23);
            this.uzytkownicyIDLabel1.TabIndex = 51;
            this.uzytkownicyIDLabel1.Text = "label2";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(211, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(509, 594);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 63;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Resize += new System.EventHandler(this.pictureBox1_Resize);
            // 
            // FUtworzFakturePreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(728, 605);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FUtworzFakturePreview";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Podgląd Faktury";
            this.Load += new System.EventHandler(this.FUtworzFakturePreview_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelIDProduktyView;
        private System.Windows.Forms.Label labelIDOdbiorcyView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnZapiszJPG;
        private System.Windows.Forms.Button btnDrukuj;
        private System.Windows.Forms.Label uzytkownicyIDLabel1;
        private System.Windows.Forms.Button btnPodgladWydruku;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnZamknij;
    }
}