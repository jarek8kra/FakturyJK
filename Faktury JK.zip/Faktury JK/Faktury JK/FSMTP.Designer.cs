﻿namespace Faktury_JK
{
    partial class FSMTP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FSMTP));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAnuluj = new System.Windows.Forms.Button();
            this.btnWyslij = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.uzytkownicyIDLabel1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtBody = new System.Windows.Forms.TextBox();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.txtDo = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtSMTP = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label6.Location = new System.Drawing.Point(228, 187);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(46, 16);
            label6.TabIndex = 82;
            label6.Text = "Treść:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label5.Location = new System.Drawing.Point(223, 368);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(74, 16);
            label5.TabIndex = 81;
            label5.Text = "Załączniki:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label4.Location = new System.Drawing.Point(223, 124);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(50, 16);
            label4.TabIndex = 80;
            label4.Text = "Temat:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            label1.Location = new System.Drawing.Point(228, 12);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(29, 16);
            label1.TabIndex = 88;
            label1.Text = "Do:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnAnuluj);
            this.panel1.Controls.Add(this.btnWyslij);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.uzytkownicyIDLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 615);
            this.panel1.TabIndex = 84;
            // 
            // btnAnuluj
            // 
            this.btnAnuluj.BackColor = System.Drawing.Color.Transparent;
            this.btnAnuluj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAnuluj.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAnuluj.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnAnuluj.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnAnuluj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnuluj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAnuluj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnAnuluj.Image = ((System.Drawing.Image)(resources.GetObject("btnAnuluj.Image")));
            this.btnAnuluj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnuluj.Location = new System.Drawing.Point(25, 137);
            this.btnAnuluj.Name = "btnAnuluj";
            this.btnAnuluj.Size = new System.Drawing.Size(150, 60);
            this.btnAnuluj.TabIndex = 55;
            this.btnAnuluj.Text = "Anuluj    ";
            this.btnAnuluj.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAnuluj.UseVisualStyleBackColor = false;
            this.btnAnuluj.Click += new System.EventHandler(this.btnAnuluj_Click);
            // 
            // btnWyslij
            // 
            this.btnWyslij.BackColor = System.Drawing.Color.Transparent;
            this.btnWyslij.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWyslij.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnWyslij.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btnWyslij.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gainsboro;
            this.btnWyslij.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWyslij.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnWyslij.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnWyslij.Image = ((System.Drawing.Image)(resources.GetObject("btnWyslij.Image")));
            this.btnWyslij.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWyslij.Location = new System.Drawing.Point(25, 62);
            this.btnWyslij.Name = "btnWyslij";
            this.btnWyslij.Size = new System.Drawing.Size(150, 60);
            this.btnWyslij.TabIndex = 54;
            this.btnWyslij.Text = "Wyślij    ";
            this.btnWyslij.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnWyslij.UseVisualStyleBackColor = false;
            this.btnWyslij.Click += new System.EventHandler(this.btnWyslij_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(21, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 20);
            this.label2.TabIndex = 50;
            this.label2.Text = "Faktura/Wyślij:";
            // 
            // uzytkownicyIDLabel1
            // 
            this.uzytkownicyIDLabel1.Location = new System.Drawing.Point(128, -32);
            this.uzytkownicyIDLabel1.Name = "uzytkownicyIDLabel1";
            this.uzytkownicyIDLabel1.Size = new System.Drawing.Size(47, 23);
            this.uzytkownicyIDLabel1.TabIndex = 51;
            this.uzytkownicyIDLabel1.Text = "label2";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(226, 387);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(697, 116);
            this.listBox1.TabIndex = 83;
            this.listBox1.TabStop = false;
            // 
            // txtBody
            // 
            this.txtBody.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtBody.Location = new System.Drawing.Point(226, 206);
            this.txtBody.MaxLength = 22;
            this.txtBody.Multiline = true;
            this.txtBody.Name = "txtBody";
            this.txtBody.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBody.Size = new System.Drawing.Size(697, 133);
            this.txtBody.TabIndex = 78;
            // 
            // txtSubject
            // 
            this.txtSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtSubject.Location = new System.Drawing.Point(226, 143);
            this.txtSubject.MaxLength = 22;
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(697, 22);
            this.txtSubject.TabIndex = 77;
            // 
            // txtDo
            // 
            this.txtDo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDo.Location = new System.Drawing.Point(226, 32);
            this.txtDo.MaxLength = 22;
            this.txtDo.Name = "txtDo";
            this.txtDo.ReadOnly = true;
            this.txtDo.Size = new System.Drawing.Size(319, 22);
            this.txtDo.TabIndex = 79;
            this.txtDo.TabStop = false;
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtUsername.Location = new System.Drawing.Point(672, 14);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = true;
            this.txtUsername.Size = new System.Drawing.Size(251, 22);
            this.txtUsername.TabIndex = 85;
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPassword.Location = new System.Drawing.Point(672, 42);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = true;
            this.txtPassword.Size = new System.Drawing.Size(251, 22);
            this.txtPassword.TabIndex = 86;
            // 
            // txtSMTP
            // 
            this.txtSMTP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtSMTP.Location = new System.Drawing.Point(672, 70);
            this.txtSMTP.Name = "txtSMTP";
            this.txtSMTP.ReadOnly = true;
            this.txtSMTP.Size = new System.Drawing.Size(251, 22);
            this.txtSMTP.TabIndex = 87;
            // 
            // FSMTP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1062, 625);
            this.Controls.Add(label1);
            this.Controls.Add(this.txtSMTP);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(label6);
            this.Controls.Add(this.txtBody);
            this.Controls.Add(label5);
            this.Controls.Add(label4);
            this.Controls.Add(this.txtSubject);
            this.Controls.Add(this.txtDo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FSMTP";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Email do odbiorcy";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FSMTP_FormClosed);
            this.Load += new System.EventHandler(this.FSMTP_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAnuluj;
        private System.Windows.Forms.Button btnWyslij;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label uzytkownicyIDLabel1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtBody;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.TextBox txtDo;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtSMTP;
    }
}