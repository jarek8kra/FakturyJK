﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Faktury_JK.ServiceReference1;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace Faktury_JK
{
    public partial class UCAPI : UserControl
    {
        public UCAPI()
        {
            InitializeComponent();
        }
        private static UCAPI _instance;
        public static UCAPI Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCAPI();
                return _instance;
            }
        }

        private void btnZaloguj_Click(object sender, EventArgs e)
        {
            ServiceReference1.ZalogujRequest zaloguj = new ZalogujRequest("d01a5305-7842-4ea8-477b-08d837406bac");
            label1.Text = zaloguj.pKluczUzytkownika;

            ServiceReference1.ZalogujResponse response = new ZalogujResponse();
            var x = response.ZalogujResult;
            label2.Text = x;//???


            ServiceReference1.DanePobierzRaportZbiorczyResponse cli = new DanePobierzRaportZbiorczyResponse();
            var y = cli.DanePobierzRaportZbiorczyResult;
            listBox1.DataSource = y;//wynik jako lista
        }
        private void btnGUSPobierz_Click(object sender, EventArgs e)
        {
            ServiceReference1.ParametryWyszukiwania pw = new ParametryWyszukiwania();
            pw.Nip = "6981624578";

            ServiceReference1.DanePobierzPelnyRaportResponse dppr = new ServiceReference1.DanePobierzPelnyRaportResponse();
            var y = dppr.DanePobierzPelnyRaportResult;
            listBox1.DataSource = y;
            dataGridView1.DataSource = y;
        }



        public void GETCityTemperature()
        {
            string url = "http://api.openweathermap.org/data/2.5/weather?q=Warsaw&units=metric&appid=e5f24bf00b129a0b6c8a35b777ba41d6";

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();

            string response;

            using (StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream()))
            {
                response = streamReader.ReadToEnd();
            }

            WeatherResponse weatherResponse = JsonConvert.DeserializeObject<WeatherResponse>(response);

            lblWeather.Text = String.Format("Temperatura w {0}: {1} °C", weatherResponse.Name, weatherResponse.Main.Temp);
        }
        class WeatherResponse
        {
            public TemperatureInfo Main { get; set; }

            public string Name { get; set; }
        }
        class TemperatureInfo
        {
            public float Temp { get; set; }
        }
        private void btnWeather_Click(object sender, EventArgs e)
        {
            GETCityTemperature();
        }


    }
}
