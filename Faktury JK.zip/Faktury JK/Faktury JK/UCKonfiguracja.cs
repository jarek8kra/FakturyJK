﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Faktury_JK
{
    public partial class UCKonfiguracja : UserControl
    {
        public UCKonfiguracja()
        {
            InitializeComponent();
        }
        private static UCKonfiguracja _instance;
        public static UCKonfiguracja Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new UCKonfiguracja();
                return _instance;
            }
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            Faktury_JK.Properties.Settings.Default.cUsernameEmail = txtUsernameEmail.Text;
            Faktury_JK.Properties.Settings.Default.cPasswordEmail = txtPasswordEmail.Text;
            Faktury_JK.Properties.Settings.Default.cSMTPEmail = txtSMTPEmail.Text;
            Faktury_JK.Properties.Settings.Default.Save();
        }

        private void UCKonfiguracja_Load(object sender, EventArgs e)
        {
            txtUsernameEmail.Text = Faktury_JK.Properties.Settings.Default.cUsernameEmail;
            txtPasswordEmail.Text = Faktury_JK.Properties.Settings.Default.cPasswordEmail;
            txtSMTPEmail.Text = Faktury_JK.Properties.Settings.Default.cSMTPEmail;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://myaccount.google.com/lesssecureapps");
        }
    }
}
